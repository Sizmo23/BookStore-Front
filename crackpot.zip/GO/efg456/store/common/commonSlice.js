import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  // allEmployees: [],
  newNotifications: [],
  productUnits: [],
  productQuality: [],
};

const commonSlice = createSlice({
  name: "commonSlice",
  initialState,
  //   reducer needs a map
  reducers: {
    saveNewNotification(state, action) {
      state.newNotifications = action.payload;
    },
    saveProductUnits(state, action) {
      state.productUnits = action.payload;
    },
    saveProductQuality(state, action) {
      state.productQuality = action.payload;
    },
  },
});

export const { saveNewNotification, saveProductUnits, saveProductQuality } =
  commonSlice.actions;

export default commonSlice.reducer;
