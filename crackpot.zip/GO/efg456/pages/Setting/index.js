"use client";
import { useState } from "react";

import { Col, Row } from "react-bootstrap";
import { FaCheck } from "react-icons/fa6";
import { MdLoop } from "react-icons/md";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import { Get, Post, Put } from "../../Axios/AxiosFunctions";
import { Button } from "../../Component/Button/Button";
import { Input } from "../../Component/Input";
import { ProfileWithEditButton } from "../../Component/ProfileWithEditButton";
import SideBarSkeleton from "../../Component/SideBarSkeleton";
import { apiHeader, BaseURL, CreateFormData } from "../../config/apiUrl";
import ChangePasswordModal from "../../modals/ChangePasswordModal";
import classes from "./Setting.module.css";
import { userAvatar } from "../../constant/imagePath";
import { useDispatch } from "react-redux";
import { updateUser } from "../../store/auth/authSlice";

export default function Profile() {
  const dispatch = useDispatch();
  const { user, access_token } = useSelector((state) => state?.authReducer);
  const [image, setImage] = useState(user?.image || userAvatar);
  const [fullName, setFullName] = useState(user?.fullName || "");
  const [modal, setModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const getUser = async () => {
    const response = await Get(BaseURL(`User`), access_token);
    if (response) {
      dispatch(updateUser(response?.data?.data));
    }
  };
  const handleSubmit = async () => {
    if (!fullName) {
      toast.error("Full Name is Required");
      return;
    }
    const formData = CreateFormData({ fullName, image });
    const apiUrl = BaseURL(`User`);
    setLoading("mainLoading");
    const response = await Put(apiUrl, formData, apiHeader(access_token));
    if (response) {
      toast.success("Profile Updated Successfully");
      await getUser();
    }
    setLoading(false);
  };
  const handleChangePassword = async (body) => {
    setLoading("password");
    const apiUrl = BaseURL("User/changepassword");
    const response = await Post(
      apiUrl,
      { email: user?.email, ...body },
      apiHeader(access_token)
    );
    if (response) {
      toast.success("Password Changed Successfully");
      setModal(false);
    }

    setLoading(false);
  };
  return (
    <SideBarSkeleton>
      <div className={classes.main}>
        <div className={classes.header}>
          <ProfileWithEditButton
            isEdit={true}
            updateImage={image}
            setUpdateImage={setImage}
          />
          <div className={classes.btns}>
            <Button
              label={"Change Password"}
              leftIcon={<MdLoop />}
              className={classes.btn}
              variant="tertiary"
              onClick={() => setModal(true)}
            />
          </div>
        </div>
        <div className={classes.form}>
          <Row>
            <Col lg={6}>
              <div className={classes.gap}>
                <Input
                  label={"Full Name:"}
                  placeholder={"Enter Full Name"}
                  value={fullName}
                  setter={setFullName}
                />
              </div>
            </Col>
            <Col lg={6}>
              <div className={classes.gap}>
                <Input
                  label={"Email:"}
                  placeholder={"admin@gmail.com"}
                  value={user?.email}
                  disabled={true}
                />
              </div>
            </Col>
          </Row>
        </div>

        <div className={classes.gap}>
          <Button
            label={loading === "mainLoading" ? "Saving..." : "Save Changes"}
            leftIcon={<FaCheck size={20} />}
            variant="tertiary"
            onClick={handleSubmit}
            disabled={loading === "mainLoading"}
          />
        </div>
      </div>

      {modal && (
        <ChangePasswordModal
          show={modal}
          setShow={setModal}
          isLoading={loading == "password"}
          handleUpdate={handleChangePassword}
        />
      )}
    </SideBarSkeleton>
  );
}
