import React, { useState } from "react";
import { Col, Row } from "react-bootstrap";
import { FaEnvelope } from "react-icons/fa6";
import { useDispatch } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { Patch, Post } from "../../Axios/AxiosFunctions";
import { Button } from "../../Component/Button/Button";
import { Input } from "../../Component/Input";
import {
  BaseURL,
  apiHeader,
  formRegEx,
  formRegExReplacer,
  parseJwt,
  validateEmail,
} from "../../config/apiUrl";
import { Logo, imageBanner } from "../../constant/imagePath";
import ForgetPasswordModal from "../../modals/ForgetPasswordModal";
import OtpModal from "../../modals/OtpModal/OtpModal";
import { saveLoginUserData } from "../../store/auth/authSlice";
import classes from "./Login.module.css";
import ConfirmPassword from "../../modals/ConfirmPassword";
import moment from "moment";
import { IoMail } from "react-icons/io5";
import { FaApple, FaKey } from "react-icons/fa";
import { FcGoogle } from "react-icons/fc";
const Login = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  // forget
  const [forgetModal, setForgetModal] = useState(false);
  const [forgetLoader, setForgetLoader] = useState(false);
  // otp---
  const [otpModal, setOtpModal] = useState(false);
  const [otpLoader, setOtpLoader] = useState(false);
  const [forgotPassEmail, setForgotPassEmail] = useState("");
  const [code, setCode] = useState("");
  // confirmPass---
  const [confirmPassModal, setConfirmPassModal] = useState(false);
  const [confirmPassLoader, setConfirmPassLoader] = useState(false);
  // resend otp -------
  const [resendOtpLoader, setResendOtpLoader] = useState(false);
  // login
  const submitHandler = async () => {
    let params = {
      verifyId: email,
      password,
    };
    for (let key in params) {
      if (!params[key]) {
        return toast.error(
          `Please fill the ${key
            .replace(formRegEx, formRegExReplacer)
            .toLowerCase()} field!`
        );
      }
    }
    if (!validateEmail(email)) {
      return toast.error("Please enter a valid email address!");
    }
    const url = BaseURL("Auth/token");

    setLoading(true);
    const response = await Post(url, params);
    if (response !== undefined) {
      const data = {
        user: parseJwt(response.data?.jwtToken),
        token: response?.data?.jwtToken,
      };

      dispatch(saveLoginUserData({ data }));
      toast.success("Login Successfully");
      navigate("/");
    }
    setLoading(false);
  };
  // forgot pass
  const handleForgotPassword = async (email) => {
    if (email == "") {
      return toast.error("Email is required");
    }
    if (!validateEmail(email)) {
      return toast.error("Please enter correct email");
    }
    return;
    const url = BaseURL(`auth/forgotPassword`);
    setForgetLoader(true);
    const response = await Post(url, { email }, apiHeader());
    if (response !== undefined) {
      toast.success(
        "OTP code has been sent successfully. Please check your email!"
      );
      setForgetModal(false);
      setOtpModal(true);
      setForgotPassEmail(email);
    }
    setForgetLoader(false);
  };
  // Otp Code
  const handleResetPassword = async (params) => {
    const url = BaseURL(`auth/verify-otp`);
    setOtpLoader(true);
    const response = await Post(url, params, apiHeader());
    if (response !== undefined) {
      toast.success("Otp code is valid. Please change your password!");
      setOtpModal(false);
      setConfirmPassModal(true);
      setCode(params?.code);
    }
    setOtpLoader(false);
  };
  // Confirm Password -----
  const handleConfirmPassword = async (params) => {
    const url = BaseURL(`auth/resetPassword`);
    setConfirmPassLoader(true);
    const response = await Patch(
      url,
      { ...params, code: Number(params?.code) },
      apiHeader()
    );
    if (response !== undefined) {
      dispatch(saveLoginUserData(response?.data));
      toast.success("Password has been changed successfully!");
      navigate("/");
      setConfirmPassModal(false);
    }
    setConfirmPassLoader(false);
  };

  // resend otp ------
  const handleResendOtp = async (email) => {
    const url = BaseURL(`auth/resend-otp`, "auth");
    setResendOtpLoader(true);
    const response = await Patch(url, { email }, apiHeader());
    if (response !== undefined) {
      toast.success(
        "OTP code has been sent successfully. Please check your email!"
      );
      setResendOtpLoader(false);
      return response;
    }
    setResendOtpLoader(false);
  };
  return (
    <>
      <main className={classes.authlayoutMain}>
        <div className={classes.colOne}>
          <div className={classes.formWrapper}>
            <div className={classes.wrapper}>
              <div className={classes.authHeading}>
                <h2 className={classes.formHeading}>Welcome To</h2>
                <p className={classes.formDescription}>FRESCO MERCADO LOCAL </p>
              </div>{" "}
              <>
                <Input
                  value={email}
                  leftIcon={<IoMail color="var(--main-color)" />}
                  setter={setEmail}
                  placeholder="Email"
                />
                <Input
                  leftIcon={<FaKey color="var(--main-color)" />}
                  value={password}
                  setter={setPassword}
                  placeholder="Password"
                  type={"password"}
                />
                <div className={classes.rememberMeWrapper}>
                  <Link className="secondary-text">Forgot Password?</Link>
                </div>
                <div className={classes.button}>
                  <Button
                    customStyle={{ width: "100%", justifyContent: "center" }}
                    onClick={submitHandler}
                    disabled={loading}
                    label={loading ? "Loading..." : "login"}
                  />
                </div>
              </>
            </div>
          </div>
        </div>
        <div className={classes.colTwo}>
          <img src={imageBanner} style={{ objectFit: "cover" }} />
        </div>
      </main>
      {forgetModal && (
        <ForgetPasswordModal
          isLoading={forgetLoader}
          handleForgotPassword={handleForgotPassword}
          setShow={setForgetModal}
          show={forgetModal}
        />
      )}
      {otpModal && (
        <OtpModal
          isOtpSend={otpLoader}
          handleOtpFunc={handleResetPassword}
          setShow={setOtpModal}
          show={otpModal}
          email={forgotPassEmail}
          resendOtp={handleResendOtp}
          resendOtpLoader={resendOtpLoader}
        />
      )}
      {confirmPassModal && (
        <ConfirmPassword
          isConfirmPass={confirmPassLoader}
          handleConfirmPass={handleConfirmPassword}
          setShow={setConfirmPassModal}
          show={confirmPassModal}
          email={forgotPassEmail}
          code={code}
        />
      )}
    </>
  );
};

export default Login;
