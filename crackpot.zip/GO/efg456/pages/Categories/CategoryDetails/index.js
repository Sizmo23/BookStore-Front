import moment from "moment";
import { useEffect, useRef, useState } from "react";
import { FiEdit, FiPlusCircle, FiTrash } from "react-icons/fi";
import { SlOptions } from "react-icons/sl";
import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { Delete, Get, Post, Put } from "../../../Axios/AxiosFunctions";
import PopperComponent from "../../../Component/PopperComponent";
import SideBarSkeleton from "../../../Component/SideBarSkeleton";
import TableStructure from "../../../Component/TableStructure";
import { BaseURL, apiHeader, recordsLimit } from "../../../config/apiUrl";
import { productsData } from "../../../config/DummyData";
import AreYouSureModal from "../../../modals/AreYouSureModal";
import classes from "./CategoryDetails.module.css";
import { Button } from "../../../Component/Button/Button";
import AddEditSubCategory from "../../../modals/AddEditSubCategory";
import { IoChevronBackOutline } from "react-icons/io5";
import { DropDown } from "../../../Component/DropDown/DropDown";
import { ProductsFilterOptions } from "../../../config/AppData";
import { FaCheck } from "react-icons/fa";
import { RxCross1 } from "react-icons/rx";

const CategoryDetails = () => {
  const navigate = useNavigate();
  const { productUnits } = useSelector((state) => state?.commonReducer);
  const category = useLocation().state?.category;
  const ref = useRef(null);
  const { access_token } = useSelector((state) => state?.authReducer);
  const [selectedItem, setSelectedItem] = useState(null);
  const [indexRef, setIndexRef] = useState(null);
  const [popper, setPopper] = useState(false);
  const [loading, setLoading] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [totalCount, setTotalCount] = useState(0);
  const [page, setPage] = useState(1);
  const [data, setData] = useState(productsData);
  const [status, setStatus] = useState(ProductsFilterOptions[0]);

  const popperHandler = (item, index) => {
    setSelectedItem({
      ...item,
      productUnitId: productUnits?.find(
        (ele) => ele?.id === item?.productUnitId
      ),
    });
    setIndexRef(index);
    setTimeout(() => {
      setPopper((prev) => !prev);
    }, 300);
  };
  const getData = async (pageNo = page, isEnabled = status?.value) => {
    const query = {
      PageNumber: pageNo,
      PageSize: recordsLimit,
      productCategoryId: category?.id,
      isEnabled: isEnabled,
    };
    const apiUrl = BaseURL(`Products?${new URLSearchParams(query).toString()}`);
    setLoading("mainLoading");
    const response = await Get(apiUrl, access_token, false);
    if (response !== undefined) {
      setData(response?.data?.data);
      setTotalCount(response?.data?.totalItems);
      setSelectedItem(null);
    } else {
      setData([]);
      setTotalCount(0);
    }
    setLoading(false);
  };
  const handleAddEdit = async (params) => {
    const body = {
      ...params,
      ...(selectedItem
        ? { id: selectedItem?.productId }
        : { productCategoryId: category?.id }),
    };
    const apiUrl = BaseURL(`Product`);
    setLoading("submitLoading");
    const response = selectedItem
      ? await Put(apiUrl, body, apiHeader(access_token))
      : await Post(apiUrl, body, apiHeader(access_token));
    if (response !== undefined) {
      setModalOpen(false);
      toast.success(
        `Sub Category ${selectedItem ? "updated" : "added"} successfully`
      );
      getData();
    }
    setLoading(false);
  };
  const handleChangeStatus = async () => {
    const params = {
      id: selectedItem?.productId,
      isEnabled: !selectedItem?.isEnabled,
    };
    const apiUrl = BaseURL(`Product/status`);
    setLoading("statusLoading");
    const response = await Put(apiUrl, params, apiHeader(access_token));
    if (response !== undefined) {
      await getData(page);
      toast.success("Sub Category status updated successfully");
      setModalOpen(false);
    }
    setLoading(false);
  };
  const handleDelete = async () => {
    const apiUrl = BaseURL(`Product?id=${selectedItem?.productId}`);
    setLoading("deleteLoading");
    const response = await Delete(apiUrl, apiHeader(access_token));
    if (response !== undefined) {
      setData(
        data?.filter((item) => item?.productId !== selectedItem?.productId)
      );
      setModalOpen(false);
      setSelectedItem(null);
      toast.success("Sub Category deleted successfully");
    }
    setLoading(false);
  };
  const popperActionHandler = (option) => {
    if (option?.value == "Delete") {
      setModalOpen("delete");
    } else if (option?.value == "Edit") {
      setModalOpen("add");
    } else {
      setModalOpen("status");
    }
  };

  useEffect(() => {
    setPage(1);
    getData(1);
  }, []);

  return (
    <SideBarSkeleton>
      <div className={classes.container}>
        <div className={classes.topBtn}>
          <Button
            leftIcon={<FiPlusCircle size={20} color={"var(--accent-color)"} />}
            onClick={() => {
              setSelectedItem(null);
              setModalOpen("add");
            }}
          >
            Add Sub Category
          </Button>
        </div>

        <div className={classes.header}>
          <div className={classes.left_header}>
            <div
              className={classes.icon}
              onClick={() => {
                navigate(-1);
              }}
            >
              <IoChevronBackOutline />
            </div>
            <h1>{category?.productCategoryName}</h1>{" "}
          </div>
          <div className={classes.searchSection}>
            <DropDown
              value={status}
              setter={(e) => {
                setStatus(e);
                setPage(1);
                getData(1, e?.value);
              }}
              options={ProductsFilterOptions}
              placeholder={"Select Status"}
            />
          </div>
        </div>

        <TableStructure
          headerHandlers={false}
          page={page}
          totalRecord={totalCount}
          isLoading={loading === "mainLoading"}
          setPage={(e) => {
            setPage(e);
            getData(e);
          }}
          headerTitle={false}
          tableHeaders={[
            {
              label: "S.No",
              value: "index",
            },
            {
              label: "Sub Category",
              value: "productName",
            },
            {
              label: "Product Unit",
              value: "productUnitId",
            },
            {
              label: "Status",
              value: "status",
            },
            {
              label: "Created At",
              value: "createdAt",
            },
            {
              label: "Actions",
              value: "action",
            },
          ]}
          tableContent={data?.map((ele, index) => ({
            ...ele,
            index: index + 1,
            status: ele?.isEnabled ? "Active" : "Inactive",
            productUnitId: productUnits?.find(
              (item) => item?.id === ele?.productUnitId
            )?.unitName,
            createdAt: moment(ele?.createdOn).format("DD-MM-YYYY"),
            action: (
              <span
                ref={indexRef === index ? ref : null}
                onClick={() => popperHandler(ele, index)}
              >
                <SlOptions color="var(--main-color)" cursor="pointer" />
              </span>
            ),
          }))}
          customStyle={{ height: "calc(100vh - 350px)" }}
        />
      </div>
      <PopperComponent
        anchorRef={ref}
        data={popperOptions?.filter((item) => {
          if (["Active", "Inactive"].includes(item.value)) {
            return item.label !== selectedItem?.isEnabled;
          }
          return item;
        })}
        open={popper}
        handleClick={popperActionHandler}
        setOpen={setPopper}
      />
      {modalOpen === "delete" && (
        <AreYouSureModal
          show={modalOpen}
          setShow={setModalOpen}
          onClick={handleDelete}
          isApiCall={loading === "deleteLoading"}
          title="Are you sure?"
          subTitle="You want to delete this sub category?"
        />
      )}
      {modalOpen === "add" && (
        <AddEditSubCategory
          show={modalOpen}
          setShow={setModalOpen}
          onClick={handleAddEdit}
          modalLoading={loading === "submitLoading"}
          data={selectedItem}
        />
      )}
      {modalOpen === "status" && (
        <AreYouSureModal
          show={modalOpen}
          setShow={setModalOpen}
          onClick={handleChangeStatus}
          isApiCall={loading === "statusLoading"}
          title="Are you sure?"
          subTitle={`You want to change the status of ${
            selectedItem?.productName
          } to ${selectedItem?.isEnabled ? "Inactive" : "Active"}`}
        />
      )}
    </SideBarSkeleton>
  );
};

export default CategoryDetails;
const popperOptions = [
  {
    icon: <FiEdit />,
    value: "Edit",
  },
  {
    icon: <FaCheck />,
    label: true,
    value: "Active",
  },
  {
    icon: <RxCross1 />,
    label: false,
    value: "Inactive",
  },
  {
    icon: <FiTrash />,
    value: "Delete",
  },
];
