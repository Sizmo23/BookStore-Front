import moment from "moment";
import { useEffect, useRef, useState } from "react";
import { FiEdit, FiEye, FiPlusCircle, FiTrash } from "react-icons/fi";
import { SlOptions } from "react-icons/sl";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { Delete, Get, Put } from "../../Axios/AxiosFunctions";
import { Button } from "../../Component/Button/Button";
import PopperComponent from "../../Component/PopperComponent";
import SideBarSkeleton from "../../Component/SideBarSkeleton";
import TableStructure from "../../Component/TableStructure";
import { BaseURL, apiHeader, recordsLimit } from "../../config/apiUrl";
import { productsData } from "../../config/DummyData";
import AreYouSureModal from "../../modals/AreYouSureModal";
import classes from "./Categories.module.css";
import useDebounce from "../../CustomHooks/useDebounce";
import SearchInput from "../../Component/SearchInput";
import { DropDown } from "../../Component/DropDown/DropDown";
import { ProductsFilterOptions } from "../../config/AppData";
import { MdCategory } from "react-icons/md";
import { FaCheck } from "react-icons/fa";
import { RxCross1 } from "react-icons/rx";
import ViewCategoryModal from "../../modals/ViewCategoryModal";

const Categories = () => {
  const ref = useRef(null);
  const { access_token } = useSelector((state) => state?.authReducer);
  const [selectedItem, setSelectedItem] = useState(null);
  const [indexRef, setIndexRef] = useState(null);
  const [popper, setPopper] = useState(false);
  const [loading, setLoading] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [totalCount, setTotalCount] = useState(0);
  const [search, setSearch] = useState("");
  const debounce = useDebounce(search, 500);
  const [page, setPage] = useState(1);
  const [data, setData] = useState(productsData);
  const [status, setStatus] = useState(ProductsFilterOptions[0]);
  const popperHandler = (item, index) => {
    setSelectedItem(item);
    setIndexRef(index);
    setTimeout(() => {
      setPopper((prev) => !prev);
    }, 300);
  };
  const navigate = useNavigate();
  const getData = async (pageNo = page, isEnabled = status?.value) => {
    const query = {
      PageNumber: pageNo,
      PageSize: recordsLimit,
      text: debounce,
      isEnabled: isEnabled,
    };
    const apiUrl = BaseURL(
      `ProductCategorys?${new URLSearchParams(query).toString()}`
    );
    setLoading("mainLoading");
    const response = await Get(apiUrl, access_token, false);
    if (response !== undefined) {
      setData(response?.data?.data);
      setTotalCount(response?.data?.totalItems);
    } else {
      setData([]);
    }
    setLoading(false);
  };
  const handleChangeStatus = async () => {
    const params = {
      id: selectedItem?.id,
      isEnabled: !selectedItem?.isEnabled,
    };
    const apiUrl = BaseURL(`ProductCategory/status`);
    setLoading("statusLoading");
    const response = await Put(apiUrl, params, apiHeader(access_token));
    if (response !== undefined) {
      await getData(page);
      toast.success("Category status updated successfully");
      setModalOpen(false);
    }
    setLoading(false);
  };
  const handleDelete = async () => {
    const apiUrl = BaseURL(`ProductCategory?id=${selectedItem?.id}`);
    setLoading("deleteLoading");
    const response = await Delete(apiUrl, apiHeader(access_token));
    if (response !== undefined) {
      setSelectedItem(null);
      setData(data?.filter((item) => item?.id !== selectedItem?.id));
      setModalOpen(false);
      toast.success("Category deleted successfully");
    }
    setLoading(false);
  };
  const popperActionHandler = (option) => {
    if (option?.value == "Sub Categories") {
      navigate(`/category-detail`, { state: { category: selectedItem } });
    } else if (option?.value == "Delete") {
      setModalOpen("delete");
    } else if (option?.value == "Edit") {
      navigate(`/add-edit-category`, { state: { category: selectedItem } });
    } else if (option?.value == "View") {
      setModalOpen("view");
    } else {
      setModalOpen("status");
    }
  };

  useEffect(() => {
    setPage(1);
    getData(1);
  }, [debounce]);

  return (
    <SideBarSkeleton>
      <div className={classes.container}>
        <div className={classes.topBtn}>
          <Button
            leftIcon={<FiPlusCircle size={20} color={"var(--accent-color)"} />}
            onClick={() => {
              navigate("/add-edit-category");
            }}
          >
            Add New Category
          </Button>
        </div>
        <div className={classes.header}>
          <h1>Categories</h1>
          <div className={classes.searchSection}>
            <SearchInput setter={setSearch} value={search} />
            <DropDown
              value={status}
              setter={(e) => {
                setStatus(e);
                setPage(1);
                getData(1, e?.value);
              }}
              options={ProductsFilterOptions}
              placeholder={"Select Status"}
            />
          </div>
        </div>

        <TableStructure
          headerHandlers={false}
          page={page}
          totalRecord={totalCount}
          isLoading={loading === "mainLoading"}
          setPage={(e) => {
            setPage(e);
            getData(e);
          }}
          headerTitle={false}
          tableHeaders={[
            {
              label: "S.No",
              value: "index",
            },
            {
              label: "Category Name",
              value: "productCategoryName",
            },
            {
              label: "Status",
              value: "status",
            },
            {
              label: "Created At",
              value: "createdAt",
            },
            {
              label: "Actions",
              value: "action",
            },
          ]}
          noDataMessage="No Categories Found"
          tableContent={data?.map((ele, index) => ({
            ...ele,
            index: index + 1,
            status: ele?.isEnabled ? "Active" : "Inactive",
            createdAt: moment(ele?.createdOn).format("DD-MM-YYYY"),
            action: (
              <span
                ref={indexRef === index ? ref : null}
                onClick={() => popperHandler(ele, index)}
              >
                <SlOptions color="var(--main-color)" cursor="pointer" />
              </span>
            ),
          }))}
          customStyle={{ height: "calc(100vh - 350px)" }}
        />
      </div>
      <PopperComponent
        anchorRef={ref}
        data={popperOptions?.filter((item) => {
          if (["Active", "Inactive"].includes(item.value)) {
            return item.label !== selectedItem?.isEnabled;
          }
          return item;
        })}
        open={popper}
        handleClick={popperActionHandler}
        setOpen={setPopper}
      />
      {modalOpen === "delete" && (
        <AreYouSureModal
          show={modalOpen}
          setShow={setModalOpen}
          onClick={handleDelete}
          isApiCall={loading === "deleteLoading"}
          title="Are you sure?"
          subTitle="You want to delete this category?"
        />
      )}
      {modalOpen === "status" && (
        <AreYouSureModal
          show={modalOpen}
          setShow={setModalOpen}
          onClick={handleChangeStatus}
          isApiCall={loading === "statusLoading"}
          title="Are you sure?"
          subTitle={`You want to change the status of ${
            selectedItem?.productCategoryName
          } to ${selectedItem?.isEnabled ? "Inactive" : "Active"}`}
        />
      )}
      {modalOpen === "view" && (
        <ViewCategoryModal
          show={modalOpen}
          setShow={setModalOpen}
          item={selectedItem}
        />
      )}
    </SideBarSkeleton>
  );
};

export default Categories;
const popperOptions = [
  {
    icon: <MdCategory />,
    value: "Sub Categories",
  },
  {
    icon: <FaCheck />,
    label: true,
    value: "Active",
  },
  {
    icon: <RxCross1 />,
    label: false,
    value: "Inactive",
  },
  {
    icon: <FiEdit />,
    value: "Edit",
  },
  {
    icon: <FiTrash />,
    value: "Delete",
  },
  {
    icon: <FiEye />,
    value: "View",
  },
];
