import { useEffect, useRef, useState } from "react";
import { GrStatusWarning } from "react-icons/gr";
import { SlOptions } from "react-icons/sl";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import { Get, Put } from "../../Axios/AxiosFunctions";
import { DropDown } from "../../Component/DropDown/DropDown";
import PopperComponent from "../../Component/PopperComponent";
import SideBarSkeleton from "../../Component/SideBarSkeleton";
import Statuses from "../../Component/Statuses/index";
import TableStructure from "../../Component/TableStructure";
import { orderStatusOptions } from "../../config/AppData";
import { ordersData } from "../../config/DummyData";
import { BaseURL, apiHeader, recordsLimit } from "../../config/apiUrl";
import ChangeOrderStatus from "../../modals/ChangeOrderStatus";
import classes from "./Orders.module.css";
import { FiEye } from "react-icons/fi";
import { useNavigate } from "react-router-dom";

const Orders = () => {
  const ref = useRef(null);
  const { access_token } = useSelector((state) => state?.authReducer);
  const [selectedItem, setSelectedItem] = useState(null);
  const [indexRef, setIndexRef] = useState(null);
  const [popper, setPopper] = useState(false);
  const [loading, setLoading] = useState(false);
  const [totalCount, setTotalCount] = useState(90);
  const [page, setPage] = useState(1);
  const [data, setData] = useState(ordersData);
  const [modalOpen, setModalOpen] = useState(false);
  const [status, setStatus] = useState(null);
  const naviagte = useNavigate();
  const popperHandler = (item, index) => {
    setSelectedItem(item);
    setIndexRef(index);
    setTimeout(() => {
      setPopper((prev) => !prev);
    }, 300);
  };
  const popperActionHandler = (option) => {
    if (option?.value == "View") {
      naviagte(`/orders/${selectedItem?.id}`);
      // setModalOpen("view");
    } else if (option?.value == "Change Status") {
      setModalOpen("status");
    }
  };

  const getData = async (pageNo = page, statusValue = status?.value) => {
    const apiUrl = BaseURL(
      `Orders?PageNumber=${pageNo}&PageSize=${recordsLimit}&orderStatusId=${statusValue}`
    );
    setLoading("mainLoading");
    const response = await Get(apiUrl, access_token, false);
    if (response !== undefined) {
      setData(response?.data?.data);
      setTotalCount(response?.data?.totalItems);
    } else {
      setData([]);
    }
    setLoading(false);
  };
  const handleStatus = async (statusValue) => {
    const params = {
      id: selectedItem?.id,
      orderStatusId: statusValue,
    };
    const apiUrl = BaseURL(
      `Order/status?${new URLSearchParams(params).toString()}`
    );
    setLoading("statusLoading");
    const response = await Put(apiUrl, {}, apiHeader(access_token));
    if (response) {
      toast.success("Status Changed Successfully");
      setSelectedItem(null);
      await getData();
      setModalOpen(false);
    }
    setLoading(false);
  };
  useEffect(() => {
    getData();
  }, []);

  return (
    <SideBarSkeleton>
      <div className={classes.container}>
        <div className={classes.header}>
          <h1>Orders</h1>{" "}
          <div className={classes.order_status}>
            <DropDown
              value={status}
              setter={(e) => {
                setStatus(e);
                setPage(1);
                getData(1, e?.value);
              }}
              options={[{ label: "All", value: "" }, ...orderStatusOptions]}
              placeholder={"Select Status"}
            />
          </div>
        </div>
        <TableStructure
          headerHandlers={false}
          headerTitle={false}
          page={page}
          totalRecord={totalCount}
          isLoading={loading === "mainLoading"}
          noDataMessage="No Orders Found"
          setPage={(e) => {
            setPage(e);
            // getData(e, search);
          }}
          tableHeaders={[
            {
              label: "Order No",
              value: "orderNo",
            },
            {
              label: "Customer Name",
              value: "customerName",
            },
            {
              label: "Total Amount",
              value: "totalAmount",
            },
            {
              label: "Status",
              value: "orderStatus",
            },
            {
              label: "Actions",
              value: "action",
              headerStyle: { textAlign: "center" },
              dataStyle: { textAlign: "center" },
            },
          ]}
          tableContent={data?.map((ele, index) => ({
            ...ele,
            totalAmount: `$ ${ele.totalAmount}`,
            status: <Statuses status={ele.status} />,
            action: (
              <span
                ref={indexRef === index ? ref : null}
                onClick={() => {
                  popperHandler(ele, index);
                }}
              >
                <SlOptions color="var(--main-color)" cursor="pointer" />
              </span>
            ),
          }))}
          customStyle={{ height: "calc(100vh - 310px)" }}
        />
      </div>
      <PopperComponent
        anchorRef={ref}
        data={popperOptions}
        open={popper}
        handleClick={popperActionHandler}
        setOpen={setPopper}
      />
      {modalOpen === "status" && (
        <ChangeOrderStatus
          show={modalOpen}
          setShow={setModalOpen}
          data={selectedItem}
          onClick={handleStatus}
          loading={loading === "statusLoading"}
        />
      )}
    </SideBarSkeleton>
  );
};

export default Orders;
const popperOptions = [
  {
    icon: <FiEye />,
    label: "View",
    value: "View",
  },
  {
    icon: <GrStatusWarning />,
    label: "Change Status",
    value: "Change Status",
  },
];
