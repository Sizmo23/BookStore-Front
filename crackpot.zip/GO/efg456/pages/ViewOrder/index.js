import React, { useEffect, useState } from "react";
import { IoChevronBack } from "react-icons/io5";
import classes from "./ViewOrder.module.css";
import { FaFileDownload } from "react-icons/fa";
import OrderDetails from "./Detail";
import { useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "../../Component/Button/Button";
import ProductInfo from "./ProductInfo";
import { Get } from "../../Axios/AxiosFunctions";
import { apiHeader, BaseURL } from "../../config/apiUrl";
import SideBarSkeleton from "../../Component/SideBarSkeleton";
import { Loader } from "../../Component/Loader";
import LoaderOrder from "./LoaderOrder";

function ViewOrder() {
  const id = useParams().id;
  const navigate = useNavigate();
  const { access_token } = useSelector((state) => state?.authReducer);
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);

  const getData = async () => {
    const apiUrl = BaseURL(`Order?id=${id}`);
    setLoading("main");
    const response = await Get(apiUrl, access_token);
    if (response !== undefined) {
      setData(response?.data?.data);
    }
    setLoading(false);
  };

  useEffect(() => {
    getData();
  }, [id]);

  const handleDownloadInvoice = () => {};
  return (
    <SideBarSkeleton>
      <div className={classes.main}>
        {loading === "main" ? (
          <LoaderOrder />
        ) : (
          <>
            <div className={classes.header}>
              <div className={classes.title}>
                <div className={classes.icon}>
                  <IoChevronBack onClick={() => navigate("/orders")} />
                </div>
                <h2>Order Details</h2>
              </div>
            </div>

            <div className={classes.orderDetails}>
              <OrderDetails data={data} />
            </div>
            <div className={classes.heroDiv}>
              <ProductInfo data={data} />
            </div>
          </>
        )}
      </div>
    </SideBarSkeleton>
  );
}

export default ViewOrder;
const details = Array(3)
  .fill("")
  .map(() => ({
    img: "/images/banana1.png",
    name: "Bananana",
    quantity: "000",
    quality: "A1",
    price: "100",
  }));
const userData = {
  firstName: "Doe",
  lastName: "John",
  country: "USA",
  address: "123 Main Street",
  phone: "123-456-7890",
  quantity: 2,
  price: 0,
  status: "pending",
};
