import React from "react";

import { Col, Row } from "react-bootstrap";
import classes from "./details.module.css";
import { userAvatar } from "../../../constant/imagePath";
function OrderDetails({ data }) {
  return (
    <div className={classes.orderInfo}>
      <div className={classes.header}>
        <div className={classes.profile}>
          <img src={userAvatar} fill alt="profile" />
        </div>

        <div className={classes.info}>
          <p className={classes.name}> {data?.userFullname}</p>
          <span>Buyer</span>
        </div>
      </div>

      <div className={classes.details}>
        <Row>
          <Col className={classes.col} md={5} sm={6}>
            <div className={classes.field}>
              <label>First Name:</label>
              <p>{data?.orderDeliveryDetail?.firstName}</p>
            </div>
          </Col>

          <Col md={7} sm={6}>
            <div className={classes.field}>
              <label>Last Name:</label>
              <p>{data?.orderDeliveryDetail?.lastName}</p>
            </div>
          </Col>

          <Col md={5} sm={6}>
            <div className={classes.field}>
              <label>Country:</label>
              <p>{data?.orderDeliveryDetail?.country}</p>
            </div>
          </Col>

          <Col md={7} sm={6}>
            <div className={classes.field}>
              <label>Address:</label>
              <p>{data?.orderDeliveryDetail?.addressLine1} </p>
            </div>
          </Col>
          <Col md={5} sm={6}>
            <div className={classes.field}>
              <label>Phone:</label>
              <p>{data?.orderDeliveryDetail?.phone}</p>
            </div>
          </Col>

          <Col md={7} sm={6}>
            <div className={classes.field}>
              <label>State:</label>
              <p>{data?.orderDeliveryDetail?.state}</p>
            </div>
          </Col>

          <Col md={12} sm={6}>
            <div className={classes.field}>
              <label>Status:</label>
              <p>{data?.orderStatusName}</p>
            </div>
          </Col>
        </Row>
      </div>
    </div>
  );
}

export default OrderDetails;
