import { Skeleton } from "@mui/material";
import React from "react";
import classes from "./LoaderOrder.module.css";
function LoaderOrder() {
  const color = "#e7e5e5";
  return (
    <>
      <div className={classes.job_card}>
        <div className={classes.header}>
          <Skeleton
            variant="circular"
            width={60}
            height={60}
            sx={{ bgcolor: color }}
          />
          <div className={classes.icons}>
            <Skeleton
              variant="rounded"
              sx={{ height: 14, width: 70, bgcolor: color }}
            />
            <Skeleton
              variant="rounded"
              sx={{ height: 14, width: 40, bgcolor: color }}
            />
          </div>
        </div>
        {Array.from({ length: 3 }).map((item, index) => (
          <div className={classes.investment_type}>
            <Skeleton
              variant="rounded"
              sx={{ height: 16, width: 120, bgcolor: color }}
            />
            <Skeleton
              variant="rounded"
              sx={{ height: 16, width: 120, bgcolor: color }}
            />
          </div>
        ))}
      </div>
      {Array.from({ length: 2 }).map((item, index) => (
        <div className={classes.job_card2}>
          <div className={classes.headerTwo}>
            <Skeleton
              variant="rounded"
              width={260}
              height={100}
              sx={{ bgcolor: color }}
            />
            <div className={classes.right}>
              <div className={classes.icons}>
                <Skeleton
                  variant="rounded"
                  sx={{
                    height: 14,
                    width: 70,
                    bgcolor: color,
                    marginBlockEnd: "10px",
                  }}
                />
                <Skeleton
                  variant="rounded"
                  sx={{
                    height: 14,
                    width: 60,
                    bgcolor: color,
                    marginBlockEnd: "10px",
                  }}
                />
                <Skeleton
                  variant="rounded"
                  sx={{
                    height: 14,
                    width: 50,
                    bgcolor: color,
                    marginBlockEnd: "10px",
                  }}
                />
              </div>
              <div className={classes.icons}>
                <Skeleton
                  variant="rounded"
                  sx={{
                    height: 14,
                    width: 70,
                    bgcolor: color,
                    marginBlockEnd: "10px",
                  }}
                />
                <Skeleton
                  variant="rounded"
                  sx={{
                    height: 14,
                    width: 60,
                    bgcolor: color,
                    marginBlockEnd: "10px",
                  }}
                />
                <Skeleton
                  variant="rounded"
                  sx={{
                    height: 14,
                    width: 50,
                    bgcolor: color,
                    marginBlockEnd: "10px",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      ))}
    </>
  );
}

export default LoaderOrder;
