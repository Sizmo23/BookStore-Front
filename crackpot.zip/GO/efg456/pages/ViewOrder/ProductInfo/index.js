import { banana } from "../../../constant/imagePath";
import classes from "./ProductInfo.module.css";

const ProductInfo = ({ data }) => {
  return (
    <>
      {data?.orderItems?.length > 0 &&
        data?.orderItems?.map((item, index) => {
          return (
            <div className={classes.main}>
              <div className={classes.imgDiv}>
                <img src={item?.img || banana} />
              </div>

              <div className={classes.contentCol}>
                <div className={classes.alignStart}>
                  <div>{item?.name}</div>
                </div>

                <div className={classes.spaceBetween}>
                  <div className={classes.infoText}>Quantity:</div>
                  <div className={classes.infoText}>
                    {item?.quantity} Kg/Dozen
                  </div>
                </div>

                <div className={classes.spaceBetween}>
                  <div className={classes.infoText}>Quality:</div>
                  <div className={classes.infoText}>
                    {item?.quality} Quality
                  </div>
                </div>

                <div className={classes.spaceBetween}>
                  <div className={classes.infoText}>Price:</div>
                  <div className={classes.infoText}>
                    ${item?.packageTotalAmount}{" "}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      <div className={classes.total}>
        <div className={classes.spaceBetween}>
          <div className={classes.item}>Total price:</div>
          <div className={classes.item}>${data?.totalAmount}</div>
        </div>
      </div>
    </>
  );
};

export default ProductInfo;
