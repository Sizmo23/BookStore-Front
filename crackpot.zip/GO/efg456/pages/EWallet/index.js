import Recharts from "../../Component/Recharts";
import { Col, Row } from "react-bootstrap";
import { FaWallet } from "react-icons/fa6";
import PieCharts from "../../Component/PieCharts/index";
import classes from "./E-Wallet.module.css";
import { FaMoneyBills } from "react-icons/fa6";
import Transactions from "../../Component/Transaction";
import { BaseURL, intToFloat } from "../../config/apiUrl";
import SideBarSkeleton from "../../Component/SideBarSkeleton";
import PieOverview from "../../Component/PieOverview";
import { FaMoneyBillAlt } from "react-icons/fa";
import TabsComponent from "../../Component/TabsComponent";
import { useEffect, useRef, useState } from "react";
import TableStructure from "../../Component/TableStructure";
import { useSelector } from "react-redux";
import Statuses from "../../Component/Statuses";
import { SlOptions } from "react-icons/sl";
import { withdrawalRequests } from "../../config/DummyData";
import { graphData } from "../../config/DummyData";
import { transactionData } from "../../config/DummyData";
import { Get } from "../../Axios/AxiosFunctions";
import PopperComponent from "../../Component/PopperComponent";
import { FaTrash } from "react-icons/fa";
import { EWalletTabsOptions } from "../../config/AppData";
import { Loader } from "../../Component/Loader";

export default function EWallet() {
  const { access_token } = useSelector((state) => state?.authReducer);
  const [currentTab, setCurrentTab] = useState(EWalletTabsOptions[0]);
  const ref = useRef(null);
  const [selectedItem, setSelectedItem] = useState(null);
  const [indexRef, setIndexRef] = useState(null);
  const [popper, setPopper] = useState(false);
  const [loading, setLoading] = useState(false);
  const [totalCount, setTotalCount] = useState(90);
  const [page, setPage] = useState(1);
  const [data, setData] = useState(withdrawalRequests);
  const [eWalletData, setEWalletData] = useState();

  const popperHandler = (item, index) => {
    setSelectedItem(item);
    setIndexRef(index);
    setTimeout(() => {
      setPopper((prev) => !prev);
    }, 300);
  };

  const getData = async () => {
    setLoading("mainLoading");
    const response = await Get(BaseURL(""), access_token);
    if (response !== undefined) {
      setEWalletData();
    }
    setLoading(false);
  };

  const popperActionHandler = (option) => {
    if (option == "delete") {
    }
  };
  useEffect(() => {
    // getData();
  }, []);

  return (
    <SideBarSkeleton>
      {loading === "mainLoading" ? (
        <Loader />
      ) : (
        <div className={classes.wrapper}>
          <div className={classes.heading}>
            <h1>E-Wallet</h1>{" "}
            <div className={classes.tabs}>
              <TabsComponent
                data={EWalletTabsOptions}
                value={currentTab}
                onClick={setCurrentTab}
              />
            </div>
          </div>

          {currentTab.value === "ewallet" ? (
            <>
              <div className={classes.chart}>
                <div className={classes.header}>
                  <h4>Total Earning This Year</h4>
                  <p>${intToFloat(21233, 2)}</p>
                </div>
                <div>
                  <Recharts data={graphData} />
                </div>
              </div>

              <Row>
                <Col xl={6} lg={12}>
                  <div className={classes.pieChartWrapper}>
                    <PieOverview
                      data={data2}
                      heading="My Earnings"
                      // onClick={() => router.push("/request-withdrawl")}
                      btnLabel="Request Withdrawal"
                    />
                  </div>
                </Col>

                <Col xl={6} lg={12} md={12}>
                  <Transactions
                    heading="Recent Transactions"
                    transactionData={transactionData}
                  />
                </Col>
              </Row>
            </>
          ) : currentTab.value === "transactions" ? (
            <>
              <TableStructure
                headerHandlers={false}
                headerTitle={false}
                page={page}
                totalRecord={totalCount}
                isLoading={loading.fetch}
                setPage={(e) => {
                  setPage(e);
                }}
                tableHeaders={[
                  {
                    label: "Vendor ID",
                    value: "vendorId",
                  },
                  {
                    label: "Vendor Name",
                    value: "vendorName",
                  },
                  {
                    label: "Amount",
                    value: "amount",
                  },
                  {
                    label: "Date",
                    value: "date",
                  },
                  {
                    label: "Status",
                    value: "status",
                  },
                  {
                    label: "Action",
                    value: "action",
                    headerStyle: { textAlign: "center" },
                    dataStyle: { textAlign: "center" },
                  },
                ]}
                tableContent={data?.map((ele, index) => ({
                  ...ele,
                  status: <Statuses status={ele.status} />,
                  action: (
                    <span
                      ref={indexRef === index ? ref : null}
                      onClick={() => popperHandler(ele, index)}
                    >
                      <SlOptions color="var(--main-color)" cursor="pointer" />
                    </span>
                  ),
                }))}
                customStyle={{ height: "calc(100vh - 310px)" }}
              />
            </>
          ) : (
            ""
          )}
        </div>
      )}
      <PopperComponent
        anchorRef={ref}
        data={popperOptions}
        open={popper}
        handleClick={popperActionHandler}
        setOpen={setPopper}
      />
    </SideBarSkeleton>
  );
}

const data1 = [
  { name: "Group A", value: 50 },
  { name: "Group B", value: 35 },
  { name: "Group C", value: 15 },
];
const data2 = [
  { name: "Group A", value: 500 },
  { name: "Group B", value: 150 },
  { name: "Group C", value: 200 },
  { name: "Group D", value: 80 },
  { name: "Group E", value: 70 },
];

const popperOptions = [
  {
    icon: <FaTrash />,
    label: "Delete",
    value: "Delete",
  },
];
