import { useEffect, useRef, useState } from "react";
import { SlOptions } from "react-icons/sl";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import { Delete, Get, Put } from "../../Axios/AxiosFunctions";
import PopperComponent from "../../Component/PopperComponent";
import SideBarSkeleton from "../../Component/SideBarSkeleton";
import TableStructure from "../../Component/TableStructure";
import TabsComponent from "../../Component/TabsComponent";
import {
  ProductsFilterOptions,
  UserManagementTabs,
} from "../../config/AppData";
import { UserManagementData } from "../../config/DummyData";
import { BaseURL, apiHeader, recordsLimit } from "../../config/apiUrl";
import AreYouSureModal from "../../modals/AreYouSureModal";
import classes from "./UserManagement.module.css";
import moment from "moment";
import { FiEye } from "react-icons/fi";
import { FaCheck } from "react-icons/fa";
import { RxCross1 } from "react-icons/rx";
import { DropDown } from "../../Component/DropDown/DropDown";

const UserManagement = () => {
  const ref = useRef(null);
  const { access_token } = useSelector((state) => state?.authReducer);
  const [selectedItem, setSelectedItem] = useState(null);
  const [indexRef, setIndexRef] = useState(null);
  const [popper, setPopper] = useState(false);
  const [loading, setLoading] = useState(false);
  const [totalCount, setTotalCount] = useState(90);
  const [currentTab, setCurrentTab] = useState(UserManagementTabs[0]);
  const [page, setPage] = useState(1);
  const [data, setData] = useState(UserManagementData);
  const [status, setStatus] = useState(ProductsFilterOptions[0]);
  const [modalOpen, setModalOpen] = useState(false);
  const popperHandler = (item, index) => {
    setSelectedItem(item);
    setIndexRef(index);
    setTimeout(() => {
      setPopper((prev) => !prev);
    }, 300);
  };

  const getData = async (
    pageNo = page,
    tab = currentTab?.value,
    statusValue = status?.value
  ) => {
    const query = {
      PageNumber: pageNo,
      PageSize: recordsLimit,
      userRoleId: tab,
      isEnabled: statusValue,
    };
    const apiUrl = BaseURL(`Users?${new URLSearchParams(query).toString()}`);
    setLoading("mainLoading");
    const response = await Get(apiUrl, access_token);
    if (response !== undefined) {
      setData(response?.data?.data);
      setTotalCount(response?.data?.totalItems);
    }
    setLoading(false);
  };
  const handleChangeStatus = async () => {
    const params = {
      id: selectedItem?.userId,
      isEnabled: !selectedItem?.isEnabled,
    };
    const apiUrl = BaseURL(`User/status`);
    setLoading("statusLoading");
    const response = await Put(apiUrl, params, apiHeader(access_token));
    if (response !== undefined) {
      await getData(page);
      toast.success("Category status updated successfully");
      setModalOpen(false);
    }
    setLoading(false);
  };
  const popperActionHandler = (option) => {
    if (option?.value == "View") {
      setModalOpen("view");
    } else {
      setModalOpen("status");
    }
  };
  useEffect(() => {
    setPage(1);
    getData(1);
  }, []);

  return (
    <SideBarSkeleton>
      <div className={classes.container}>
        <div className={classes.heading}>
          <h1>User Management</h1>{" "}
          <div className={classes.right_header}>
            <div className={classes.tabs}>
              <TabsComponent
                data={UserManagementTabs}
                value={currentTab}
                onClick={(e) => {
                  setCurrentTab(e);
                  getData(1, e?.value);
                }}
              />
            </div>
            <div>
              <DropDown
                value={status}
                setter={(e) => {
                  setStatus(e);
                  setPage(1);
                  getData(1, currentTab?.value, e?.value);
                }}
                customStyle={{
                  // padding:'-1px'
                  width: "150px",
                  minHeight: "25px",
                  height: "47px",
                }}
                options={ProductsFilterOptions}
                placeholder={"Select Status"}
              />
            </div>
          </div>
        </div>
        <TableStructure
          headerHandlers={false}
          page={page}
          totalRecord={totalCount}
          isLoading={loading === "mainLoading"}
          setPage={(e) => {
            setPage(e);
            getData(e, currentTab?.value);
          }}
          headerTitle={false}
          tableHeaders={[
            {
              label: currentTab?.value == "Buyers" ? "Buyer ID" : "Vendor ID",
              value: "userId",
            },
            {
              label:
                currentTab?.value == "Buyers" ? "Buyer Name" : "Vendor Name",
              value: "userName",
            },
            {
              label: "Status",
              value: "status",
            },
            {
              label: "Joining Date",
              value: "date",
            },

            {
              label: "Action",
              value: "action",
              headerStyle: { textAlign: "center" },
              dataStyle: { textAlign: "center" },
            },
          ]}
          tableContent={data?.map((ele, index) => ({
            ...ele,
            status: ele?.isEnabled ? "Active" : "Inactive",
            date: moment(ele?.dateJoined).format("DD-MM-YYYY"),
            action: (
              <span
                ref={indexRef === index ? ref : null}
                onClick={() => popperHandler(ele, index)}
              >
                <SlOptions color="var(--main-color)" cursor="pointer" />
              </span>
            ),
          }))}
          customStyle={{ height: "calc(100vh - 350px)" }}
        />
      </div>
      <PopperComponent
        anchorRef={ref}
        data={popperOptions?.filter((item) => {
          if (["Active", "Inactive"].includes(item.value)) {
            return item.label !== selectedItem?.isEnabled;
          }
          return item;
        })}
        open={popper}
        handleClick={popperActionHandler}
        setOpen={setPopper}
      />
      {modalOpen === "status" && (
        <AreYouSureModal
          setShow={setModalOpen}
          isApiCall={loading === "statusLoading"}
          show={modalOpen}
          onClick={handleChangeStatus}
          title={`Are you sure ?`}
          subTitle={`You want to ${
            selectedItem?.isEnabled ? "Deactivate" : "Activate"
          } ${selectedItem?.userName}`}
        />
      )}
    </SideBarSkeleton>
  );
};

export default UserManagement;
const popperOptions = [
  {
    icon: <FaCheck />,
    label: true,
    value: "Active",
  },
  {
    icon: <RxCross1 />,
    label: false,
    value: "Inactive",
  },
];
