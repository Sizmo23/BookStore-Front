import { Skeleton } from "@mui/material";
import moment from "moment";
import React, { useEffect, useRef, useState } from "react";
import { Col, Row, Spinner } from "react-bootstrap";
import { BiDotsVerticalRounded } from "react-icons/bi";
import { BsChevronLeft } from "react-icons/bs";
import { RiSendPlaneFill } from "react-icons/ri";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import { Get, Patch, Post } from "../../Axios/AxiosFunctions";
import { Button } from "../../Component/Button/Button";
import { DropDown } from "../../Component/DropDown/DropDown";
import { Loader } from "../../Component/Loader";
import NoData from "../../Component/NoData/NoData";
import PoperComponent from "../../Component/PopperComponent";
import SearchInput from "../../Component/SearchInput";
import SideBarSkeleton from "../../Component/SideBarSkeleton";
import {
  BaseURL,
  apiHeader,
  imageUrl,
  recordsLimit,
} from "../../config/apiUrl";
import { isMobileViewHook } from "../../CustomHooks/isMobileViewHook";
import useDebounce from "../../CustomHooks/useDebounce";
import AddMemberModal from "../../modals/AddMemberModal";
import SendMessageModal from "../../modals/SendMessageModal";
import classes from "./Chat.module.css";

let socketConnection = null; //io(BaseURL("/"), { transports: ["websocket"] });
const chatRecordLimit = 30;

const SendInput = ({ sendMsg, scrollToBottom }) => {
  const [messageText, setMessageText] = useState("");
  return (
    <div className={classes.chatInput_box}>
      <input
        onKeyDown={async (e) => {
          if (e.key == "Enter") {
            await sendMsg(messageText);
            await scrollToBottom();
            setMessageText("");
          }
        }}
        type="text"
        placeholder="Type Your Message Here..."
        value={messageText}
        onChange={(e) => setMessageText(e.target.value)}
        className={classes.__input}
      />
      <div className={classes.input_icon}>
        <span
          onClick={async () => {
            await sendMsg(messageText);
            await scrollToBottom();
            setMessageText("");
          }}
          className={classes.snd_btn}
        >
          <RiSendPlaneFill
            className={classes.send_icon}
            size={24}
            color={"var(--white-color)"}
          />
        </span>
      </div>
    </div>
  );
};

const RenderChat = ({ item, userData }) => {
  const decideChatUser = item?.from == userData?._id;
  return (
    <>
      {/* make messages to date wise  */}

      {item?.type == "event" ? (
        <div className={[classes.eventInfoMessageDiv].join(" ")}>
          <p>{item?.message?.text}</p>
        </div>
      ) : decideChatUser ? (
        <div className={[classes.chatBoxMe].join(" ")}>
          <div className={classes.chatStyling}>
            <p>{item?.message?.text}</p>
          </div>
          <div className={classes.imgBox}>
            <img src={imageUrl(item?.message?.user?.avatar)} alt="..." />
          </div>
          <p className={classes.dateTime}>
            <span>{moment(item?.createdAt).format("h:mm a")}</span>
          </p>
          <p className={classes.name}>{item?.message?.user?.userName}</p>
        </div>
      ) : (
        <div className={[classes.chatBox].join(" ")}>
          <div className={classes.imgBox}>
            <img src={imageUrl(item?.message?.user?.avatar)} alt="..." />
          </div>
          <div className={classes.chatStyling}>
            <p>{item?.message?.text}</p>
          </div>
          <p className={classes.dateTime}>
            <span>{moment(item?.createdAt).format("h:mm a")}</span>
          </p>
          <p className={classes.name}>{item?.message?.user?.userName}</p>
        </div>
      )}
    </>
  );
};

const RoomBox = ({
  item,
  selectedRoom,
  setSelectedRoom,
  setChatsPage,
  setChatsData,
  setRoomsData,
}) => {
  const userData = useSelector((state) => state?.authReducer?.user);

  const decideRoomUser = item?.users
    ?.map((e) => e?.userId)
    ?.find((e) => e?.superAgent?._id !== userData?.superAgent?._id);
  const { unreadCount } = item?.users?.find(
    (e) => e?.userId?._id == userData?._id
  ) ?? { unreadCount: 0 };
  let upadatedUsers = JSON.parse(JSON.stringify(item?.users));
  upadatedUsers?.forEach((item) => {
    if (item?.userId?._id === userData?._id) {
      item.unreadCount = 0;
    }
  });
  let agencyLogo = item?.users?.[0]?.userId?.superAgent?.agency?.logo;

  const decideAgencyUser = item?.users?.find(
    (e) => e?.userId?._id !== userData?._id
  )?.userId;

  return (
    <div
      className={[
        classes.roomBox,
        selectedRoom?._id === item?._id && classes.active,
      ].join(" ")}
      onClick={() => {
        if (selectedRoom?._id !== item?._id) {
          setChatsPage(1);
          setChatsData([]);
          setSelectedRoom(item);
        }
        setRoomsData((prev) => {
          const updatedRoomLastMessage = prev?.map((innerItem) => {
            if (innerItem?._id == item?._id) {
              return {
                ...innerItem,
                users: upadatedUsers,
              };
            }
            return innerItem;
          });

          return updatedRoomLastMessage;
        });
      }}
    >
      <div className={classes.roomImgDiv}>
        {item?.type == "agency" ? (
          <img src={imageUrl(agencyLogo)} alt="..." />
        ) : item?.title !== null ? (
          <img src={imageUrl(decideAgencyUser?.photo)} alt="..." />
        ) : (
          <img src={imageUrl(decideRoomUser?.photo)} alt="..." />
        )}
      </div>
      <div className={classes.details}>
        {item?.title && <p className={classes.name}>{item?.title}</p>}
        {item?.from && (
          <p className={classes.name}>
            {" "}
            {decideRoomUser?.firstName} {decideRoomUser?.lastName} -{" "}
            {decideRoomUser?.superAgent?.agency?.name}
          </p>
        )}
        {item?.subject && (
          <p className={classes.name}>Subject: {item?.subject}</p>
        )}
        <p className={classes.text}>
          {item?.lastMessage
            ? `${item?.lastMessage?.text?.slice(0, 20)}...`
            : "No Message"}
        </p>
        {item?.lastMessage && (
          <div className={classes.date}>
            <p>
              {moment(item?.lastMessage?.updatedAt).format("DD-MM-YYYY") ==
              moment().format("DD-MM-YYYY")
                ? moment(item?.lastMessage?.updatedAt).format("h:mm a")
                : moment(item?.lastMessage?.updatedAt).format("DD/MM/YYYY")}
            </p>
          </div>
        )}
      </div>

      {unreadCount > 0 && (
        <div className={classes.unreadCount}>{unreadCount}</div>
      )}
    </div>
  );
};

const RenderRoom = ({
  roomsData,
  roomsLoading,
  selectedRoom,
  setSelectedRoom,
  roomsPage,
  roomsTotalCount,
  setRoomsPage,
  search,
  setSearch,
  setChatsPage,
  setChatsData,
  setRoomsData,
  setIsMessageModal,
  getAllRooms,
  filter,
  setFilter,
}) => {
  return (
    <div className={classes.roomWrapper}>
      <div className={classes.roomHeader}>
        <h4>Chat</h4>
        <DropDown
          value={filter}
          setFilter={setFilter}
          options={[
            { label: "Requested Projects", value: "requested-projects" },
            { label: "Completed Projects", value: "completed-projects" },
            { label: "Sub-contractor", value: "sub-contractor" },
            { label: "Active Projects", value: "active-projects" },
          ]}
          customStyle={{ backgroundColor: "var(--secondary-color)" }}
          isSearchable={false}
          indicatorColor="var(--white-color)"
          singleValueColor="var(--white-color)"
          placeholder={"Filter"}
          placeholderColor="var(--white-color)"
        />
        {/*         <Button label={"New Message"} onClick={() => setIsMessageModal(true)} /> */}
      </div>
      <div className={classes.searchInputDiv}>
        <SearchInput
          value={search}
          setter={setSearch}
          placeholder={"Search"}
          customStyle={{
            width: "100%",
            backgroundColor: "var(--section-background-light)",
            padding: "15px",
          }}
          inputStyle={{ border: "none" }}
        />
      </div>

      <div className={classes.horizontalLine}>
        <hr />
      </div>

      <div className={classes.__list}>
        <h5>All Chats</h5>
        {roomsLoading == "mainLoading" ? (
          Array.from(new Array(10)).map((item, i) => (
            <div className="mb-2">
              <Skeleton variant="rectangular" width={"100%"} height={100} />
            </div>
          ))
        ) : roomsData?.length > 0 ? (
          roomsData?.map((item, i) => {
            return (
              <RoomBox
                item={item}
                selectedRoom={selectedRoom}
                setSelectedRoom={setSelectedRoom}
                setChatsPage={setChatsPage}
                setChatsData={setChatsData}
                setRoomsData={setRoomsData}
                key={i}
              />
            );
          })
        ) : (
          <NoData text="No Rooms Found" />
        )}
      </div>
      {roomsPage < Math.ceil(roomsTotalCount / recordsLimit) && (
        <div className={classes.showMore}>
          {roomsLoading === "showMoreLoading" ? (
            <Spinner animation="border" />
          ) : (
            <Button
              label={"Show More"}
              onClick={() => {
                setRoomsPage((prev) => prev + 1);
                getAllRooms(roomsPage + 1, roomsData, "showMoreLoading");
              }}
            />
          )}
        </div>
      )}
    </div>
  );
};

const RenderChats = ({
  selectedRoom,
  chatsData,
  chatsLoading,
  chatsPage,
  chatsTotalCount,
  setChatsPage,
  isMobile,
  scrollToBottom,
  sendMsg,
  msgEndRef,
  getAllChats,
  setSelectedRoom,
  handleToggle,
  anchorRef,
  //
  roomsData,
  setRoomsData,
}) => {
  const { access_token: accessToken, user: userData } = useSelector(
    (state) => state?.authReducer
  );
  // listing owner or super agent
  const listingOwnerOrSuperAgent = [
    selectedRoom?.listing?.owner,
    selectedRoom?.listing?.superAgent,
  ].includes(userData?._id);
  // chat started from or super agent
  const chartStartedFrom =
    // check condition if super agent or chat started from is same
    selectedRoom?.users?.[0]?.userId?._id ==
    selectedRoom?.users?.[0]?.userId?.superAgent?._id
      ? [selectedRoom?.users?.[0]?.userId?._id].includes(userData?._id)
      : [
          selectedRoom?.users?.[0]?.userId?._id,
          selectedRoom?.users?.[2]?.userId?._id,
        ].includes(userData?._id);

  const decideRoomUser = selectedRoom?.users
    ?.map((e) => e?.userId)
    ?.find((e) => e?.superAgent?._id !== userData?.superAgent?._id);

  // view confirm event
  const [addingEvent, setAddingEvent] = useState({
    open: false,
    loading: false,
  });

  // add event
  const addEventClick = async (params) => {
    const url = BaseURL("chats/update", "chat");
    return;
    let body = {
      ...params,
      listing: selectedRoom?.listing?._id,
      roomId: selectedRoom?._id,
    };
    setAddingEvent((prev) => ({ ...prev, loading: params?.loading }));
    const response = await Patch(url, body, apiHeader(accessToken));
    if (response !== undefined) {
      setSelectedRoom(response?.data?.data);
      let tempRoomsData = [...roomsData];
      let roomIndex = tempRoomsData?.findIndex(
        (item) => item?._id === response?.data?.data?._id
      );
      tempRoomsData[roomIndex] = response?.data?.data;
      setRoomsData(tempRoomsData);
      setAddingEvent((prev) => ({ ...prev, open: false }));
      toast.success("Successfully Added");
    }
    setAddingEvent((prev) => ({ ...prev, loading: false }));
  };
  return (
    <div className={classes.chatWrapper}>
      <div className={classes.chatHeader}>
        {isMobile && (
          <BsChevronLeft
            onClick={() => setSelectedRoom(null)}
            size={30}
            color={"var(--white-color)"}
          />
        )}
        <div className={classes.userDetails}>
          {/* <div className={classes.img}>
            <img src={imageUrl(selectedRoom?.product?.images?.[0])} alt="..." />
          </div> */}
          <div>
            <p>{selectedRoom?.title && selectedRoom?.title}</p>
            {selectedRoom?.from && (
              <p className={classes.name}>
                {" "}
                {decideRoomUser?.firstName} {decideRoomUser?.lastName} -{" "}
                <a
                  className={classes.contactLink}
                  href={`https://wa.me/${decideRoomUser?.contact}`}
                >
                  {decideRoomUser?.contact}
                </a>{" "}
                -{" "}
                <span className={classes.redirectLink}>
                  {decideRoomUser?.superAgent?.agency?.name}
                </span>
              </p>
            )}
            <p>
              {selectedRoom?.subject && `Subject: ${selectedRoom?.subject}`}
            </p>
            {selectedRoom?.listing?.systemReference && (
              <p className={classes.propertyLink}>
                System Reference:{" "}
                <span
                  onClick={() => {
                    window.open(
                      window.location.origin +
                        `/property/${selectedRoom?.listing?.systemReference}`,
                      "_blank"
                    );
                  }}
                >
                  {selectedRoom?.listing?.systemReference}
                </span>
              </p>
            )}
          </div>
        </div>
        {selectedRoom?.type == "normal" &&
          !selectedRoom?.leavedUsers?.includes(userData?._id) && (
            <div
              ref={anchorRef}
              id="composition-button"
              aria-haspopup="true"
              onClick={() => {
                handleToggle();
              }}
            >
              <BiDotsVerticalRounded size={22} color={"#fff"} />
            </div>
          )}
      </div>
      <div className={classes.chatBody}>
        {!chatsLoading &&
          chatsTotalCount > 1 &&
          chatsTotalCount >= chatsPage && (
            <div className={classes.loadMoreBtnDiv}>
              <Button
                label={"Load More"}
                className={classes.loadMoreBtn}
                onClick={() => {
                  const incPage = ++chatsPage;
                  getAllChats(incPage);
                  setChatsPage(incPage);
                }}
              />
            </div>
          )}
        {chatsLoading ? (
          <Loader />
        ) : chatsData?.length > 0 ? (
          [...chatsData].reverse()?.map?.((item, i) => {
            return (
              <>
                {/* {moment(item?.createdAt).format("DD-MM-YYYY") !==
                  moment(chatsData[i - 1]?.createdAt).format("DD-MM-YYYY") && (
                  <div className={classes.dateInChatDiv}>
                    <p>{moment(item?.createdAt).format("DD-MM-YYYY")}</p>
                  </div>
                )} */}
                {i === 0 ||
                moment(item?.createdAt).format("DD-MM-YYYY") !==
                  moment([...chatsData].reverse()[i - 1]?.createdAt).format(
                    "DD-MM-YYYY"
                  ) ? (
                  <div className={classes.dateInChatDiv}>
                    <p>{moment(item?.createdAt).format("DD-MM-YYYY")}</p>
                  </div>
                ) : null}

                <RenderChat item={item} userData={userData} key={i} />
              </>
            );
          })
        ) : (
          <NoData text={"No Messages"} />
        )}
        <div ref={msgEndRef} />
      </div>
      {/* book a viewing */}
      {selectedRoom?.chatOptions == "book-a-viewing" && (
        <div>
          {listingOwnerOrSuperAgent &&
            selectedRoom?.viewingConfirmed == "none" && (
              <div className={classes.automatedResponseDiv}>
                <p>Is this Viewing Confirmed? </p>
                <p>
                  <span
                    className={classes.yesBtn}
                    onClick={() => {
                      if (addingEvent?.loading == "yes") return;
                      setAddingEvent((prev) => ({ ...prev, open: true }));
                    }}
                  >
                    Yes
                  </span>{" "}
                  <span
                    className={classes.noBtn}
                    onClick={() => {
                      if (addingEvent?.loading == "no") return;
                      addEventClick({ viewingConfirmed: "no", loading: "no" });
                    }}
                  >
                    {addingEvent?.loading == "no" ? "Loading..." : "No"}
                  </span>
                </p>
              </div>
            )}
          {chartStartedFrom &&
            selectedRoom?.eventConfirmed == "none" &&
            selectedRoom?.viewingConfirmed == "yes" && (
              <div className={classes.automatedResponseDiv}>
                <p>Add this Viewing to Calendar? </p>
                <p>
                  <span
                    className={classes.yesBtn}
                    onClick={() => {
                      if (addingEvent?.loading == "yes") return;
                      addEventClick({ eventConfirmed: "yes", loading: "yes" });
                    }}
                  >
                    {addingEvent?.loading == "yes" ? "Loading..." : "Yes"}
                  </span>{" "}
                  <span
                    className={classes.noBtn}
                    onClick={() => {
                      if (addingEvent?.loading == "no") return;
                      addEventClick({ eventConfirmed: "no", loading: "no" });
                    }}
                  >
                    {addingEvent?.loading == "no" ? "Loading..." : "No"}
                  </span>
                </p>
              </div>
            )}
        </div>
      )}
      {/* check availability */}
      {selectedRoom?.chatOptions == "check-availability" && (
        <div>
          {/* property available */}
          {listingOwnerOrSuperAgent &&
            selectedRoom?.propertyAvailable == "none" && (
              <div className={classes.automatedResponseDiv}>
                <p>Confirm Availability? </p>
                <p>
                  <span
                    className={classes.yesBtn}
                    onClick={() => {
                      if (addingEvent?.loading == "yes") return;
                      addEventClick({
                        propertyAvailable: "yes",
                        loading: "yes",
                      });
                    }}
                  >
                    {addingEvent?.loading == "yes" ? "Loading..." : "Yes"}
                  </span>{" "}
                  <span
                    className={classes.noBtn}
                    onClick={() => {
                      if (addingEvent?.loading == "no") return;
                      addEventClick({ propertyAvailable: "no", loading: "no" });
                    }}
                  >
                    {addingEvent?.loading == "no" ? "Loading..." : "No"}
                  </span>
                </p>
              </div>
            )}
          {/* booking request */}
          {chartStartedFrom &&
            selectedRoom?.propertyAvailable == "yes" &&
            selectedRoom?.bookingRequest == "none" &&
            selectedRoom?.viewingConfirmed == "none" &&
            selectedRoom?.bookingConfirmed == "none" && (
              <div className={classes.automatedResponseDiv}>
                <p>Would you like to book a viewing? </p>
                <p>
                  <span
                    className={classes.yesBtn}
                    onClick={() => {
                      if (addingEvent?.loading == "yes") return;
                      setAddingEvent((prev) => ({ ...prev, open: true }));
                    }}
                  >
                    Yes
                  </span>{" "}
                  <span
                    className={classes.noBtn}
                    onClick={() => {
                      if (addingEvent?.loading == "no") return;
                      addEventClick({ bookingRequest: "no", loading: "no" });
                    }}
                  >
                    {addingEvent?.loading == "no" ? "Loading..." : "No"}
                  </span>
                </p>
              </div>
            )}
          {/* event add */}
          {listingOwnerOrSuperAgent &&
            selectedRoom?.viewingConfirmed == "none" &&
            selectedRoom?.bookingRequest == "yes" && (
              <div className={classes.automatedResponseDiv}>
                <p>Is this Viewing Confirmed? </p>
                <p>
                  <span
                    className={classes.yesBtn}
                    onClick={() => {
                      if (addingEvent?.loading == "yes") return;
                      setAddingEvent((prev) => ({ ...prev, open: true }));
                    }}
                  >
                    Yes
                  </span>{" "}
                  <span
                    className={classes.noBtn}
                    onClick={() => {
                      if (addingEvent?.loading == "no") return;
                      addEventClick({ viewingConfirmed: "no", loading: "no" });
                    }}
                  >
                    {addingEvent?.loading == "no" ? "Loading..." : "No"}
                  </span>
                </p>
              </div>
            )}
          {/* add viewing to calendar */}
          {chartStartedFrom &&
            selectedRoom?.eventConfirmed == "none" &&
            selectedRoom?.viewingConfirmed == "yes" && (
              <div className={classes.automatedResponseDiv}>
                <p>Add this Viewing to Calendar? </p>
                <p>
                  <span
                    className={classes.yesBtn}
                    onClick={() => {
                      if (addingEvent?.loading == "yes") return;
                      addEventClick({ eventConfirmed: "yes", loading: "yes" });
                    }}
                  >
                    {addingEvent?.loading == "yes" ? "Loading..." : "Yes"}
                  </span>{" "}
                  <span
                    className={classes.noBtn}
                    onClick={() => {
                      if (addingEvent?.loading == "no") return;
                      addEventClick({ eventConfirmed: "no", loading: "no" });
                    }}
                  >
                    {addingEvent?.loading == "no" ? "Loading..." : "No"}
                  </span>
                </p>
              </div>
            )}
        </div>
      )}
      {/* for leaved users */}
      {selectedRoom?.leavedUsers?.includes(userData?._id) ? (
        <div className={classes.removedMessage}>
          <p className={classes.text}>You have been removed from this chat</p>
        </div>
      ) : (
        <div className={classes.chatFooter}>
          <SendInput sendMsg={sendMsg} scrollToBottom={scrollToBottom} />
        </div>
      )}
      {/* <div ref={msgEndRef} /> */}
    </div>
  );
};

export default function Chat() {
  const { access_token: token, user: u } = useSelector(
    (state) => state?.authReducer
  );
  const user = {
    firstName: "Lorem",
    lastName: "Ipsum",
  };
  const access_token =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2Mzk0NDMxNTE4Y2I0MWE2OTAyMGQ0OCIsImlhdCI6MTcxNzAwODYzMCwiZXhwIjoxNzI0Nzg0NjMwfQ.9x9JY6e9VVnf4EL5zCoUVHPPwP8CLKFT5di2gU25Pqc";
  const roomDataFromLocation = null; // useLocation()?.state;
  const msgEndRef = useRef(null);
  const [isMobile, setIsMobile] = useState(false);
  // room and chat data state
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [roomsData, setRoomsData] = useState([]);
  const [roomsLoading, setRoomsLoading] = useState(false);
  const [chatsData, setChatsData] = useState([]);
  const [chatsLoading, setChatsLoading] = useState(false);
  // pagination state
  const [roomsPage, setRoomsPage] = useState(1);
  const [roomsTotalCount, setRoomsTotalCount] = useState(1);
  const [chatsPage, setChatsPage] = useState(1);
  const [chatsTotalCount, setChatsTotalCount] = useState(1);
  // search for room
  const [search, setSearch] = useState("");
  const debounceSearchTerm = useDebounce(search, 500);
  // send message
  const [isSending, setIsSending] = useState(false);
  const [isMessageModal, setIsMessageModal] = useState(false);
  // all agents
  const [allAgents, setAllAgents] = useState([]);
  // popper
  const [openPopper, setOpenPopper] = useState(false);
  const anchorRef = useRef(null);
  // add member
  const [addMemberModal, setAddMemberModal] = useState(false);
  const [addMemberLoading, setAddMemberLoading] = useState(false);
  const [filter, setFilter] = useState(null);

  // handle toggle
  const handleToggle = () => {
    setOpenPopper((prevOpen) => !prevOpen);
  };
  // scroll to bottom
  function scrollToBottom() {
    msgEndRef.current?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }
  // get all agents
  const getAllAgents = async () => {
    const apiUrl = BaseURL(`users/all-agents`, "auth");
    return;
    const response = await Get(apiUrl, access_token);
    if (response !== undefined) {
      setAllAgents(response?.data?.data?.users);
    }
  };
  // get all rooms
  const getAllRooms = async (
    page = roomsPage,
    prev = [],
    loading = "mainLoading"
  ) => {
    const apiUrl = BaseURL(
      `chats?page=${page}&limit=${recordsLimit}&search=${search}`,
      "chat"
    );
    return;
    setRoomsLoading(loading);
    const response = await Get(apiUrl, access_token);
    if (response !== undefined) {
      setRoomsData([...prev, ...response?.data?.data?.rooms]);
      setRoomsTotalCount(response?.data?.data?.totalCount);
      if (typeof roomDataFromLocation == "string") {
        setSelectedRoom(
          response?.data?.data?.rooms?.find(
            (e) => e?._id == roomDataFromLocation
          )
        );
      }
    }
    setRoomsLoading(false);
  };
  // get all chats
  const getAllChats = async (page = chatsPage, _selectedRoom) => {
    const apiUrl = BaseURL(
      `chats/messages/${
        _selectedRoom ? _selectedRoom?._id : selectedRoom?._id
      }?page=${page}&limit=${chatRecordLimit}`,
      "chat"
    );
    return;
    page == 1 && setChatsLoading(true);
    const response = await Get(apiUrl, access_token);
    if (response !== undefined) {
      if (page == 1) setChatsData(response?.data?.data?.data);
      else setChatsData([...chatsData, ...response?.data?.data?.data]);
      setChatsTotalCount(
        Math.ceil(response?.data?.data?.totalCount / chatRecordLimit)
      );
    }
    page == 1 && setChatsLoading(false);
    page == 1 && scrollToBottom();
  };
  // send message
  const sendMsg = (e) => {
    if (e == "") {
      return;
    }

    const msg = {
      from: user?._id,
      message: {
        text: e,
        user: {
          _id: user?._id,
          avatar: user?.photo,
          userName: `${user.firstName} ${user.lastName}`,
        },
      },
      createdAt: moment().format(),
    };
    const newData = [...chatsData];
    newData.unshift(msg);
    setChatsData(newData);
    socketConnection?.emit("msg", {
      ...msg,
      roomId: selectedRoom?._id,
    });
    setRoomsData((pre) => {
      const roomIndex = pre?.findIndex(
        (innerItem) => innerItem?._id === selectedRoom?._id
      );
      if (roomIndex !== -1) {
        const updatedRoom = {
          ...pre[roomIndex],
          lastMessage: msg.message,
          createdAt: msg.createdAt,
        };
        const updatedRoomsData = [
          updatedRoom,
          ...pre.slice(0, roomIndex),
          ...pre.slice(roomIndex + 1),
        ];
        return updatedRoomsData;
      } else {
        return [...pre];
      }
    });
    return;
  };
  // socket connection
  useEffect(() => {
    getAllAgents();
    isMobileViewHook(setIsMobile, 1024);
    socketConnection?.emit("join", { id: user?._id });
    return () => {
      socketConnection?.emit("disconnected", { id: user?._id });
    };
  }, []);
  // rooms search
  useEffect(() => {
    getAllRooms(1, [], "mainLoading");
  }, [debounceSearchTerm]);
  // socket for selected room messages
  useEffect(() => {
    if (selectedRoom !== null) {
      getAllChats();
      socketConnection?.emit("chatJoin", {
        userId: user?._id,
        roomId: selectedRoom?._id,
      });
      socketConnection?.emit("mark-as-read", {
        roomId: selectedRoom?._id,
        userId: user?._id,
      });
      socketConnection?.on("msg", (msg, room, wholeRoom) => {
        if (selectedRoom?._id == room && msg.user?._id !== user?._id) {
          setChatsData((prev) => [msg, ...prev]);
          socketConnection?.emit("mark-as-read", {
            roomId: selectedRoom?._id,
            userId: user?._id,
          });
          scrollToBottom();
        }
        if (wholeRoom) {
          setRoomsData((pre) => {
            // Check if the room is already in the roomsData array
            const roomIndex = pre?.findIndex(
              (innerItem) => innerItem?._id === wholeRoom?._id
            );
            if (roomIndex !== -1) {
              // Room found, update the last message and users
              const updatedRoom = {
                ...pre[roomIndex],
                lastMessage: wholeRoom?.lastMessage,
                users: wholeRoom?.users,
              };
              // Move the updated room to the beginning of the array
              const updatedRoomsData = [
                updatedRoom,
                ...pre.slice(0, roomIndex),
                ...pre.slice(roomIndex + 1),
              ];
              return updatedRoomsData;
            } else {
              // Room not found, return the original array
              return [...pre];
            }
          });
        }
      });
    }
    // new room from socket
    socketConnection?.on("newRoom", (msg) => {
      let usersInRoom = msg?.room?.users?.map((e) => e?.userId?._id);
      if (
        usersInRoom?.includes(user?._id) &&
        !usersInRoom?.includes(msg?.roomCreatedBy)
      ) {
        setRoomsData((pre) => [msg?.room, ...pre]);
      }
    });
    // members added to room socket
    socketConnection?.on("roomUpdated", ({ room, newUsers, leavedUsers }) => {
      if (newUsers?.includes(user?._id)) {
        if (room?._id == selectedRoom?._id) {
          setSelectedRoom(room);
        }
        setRoomsData((pre) => {
          // Check if the room is already in the roomsData array
          const roomIndex = pre?.findIndex(
            (innerItem) => innerItem?._id === room?._id
          );
          if (roomIndex !== -1) {
            // Room is already present, update it
            const updatedRoomsData = pre.map((innerItem) => {
              if (innerItem?._id === room?._id) {
                return {
                  ...innerItem,
                  leavedUsers: innerItem?.leavedUsers?.filter(
                    (item) => item !== user?._id
                  ),
                  users: [...innerItem?.users, { userId: { _id: user?._id } }],
                };
              }
              return innerItem;
            });

            return updatedRoomsData;
          } else {
            // Room is not present, add it
            return [room, ...pre];
          }
        });
      }
      if (leavedUsers?.includes(user?._id)) {
        setRoomsData((pre) => {
          const updatedRoomLastMessage = pre?.map((innerItem) => {
            if (innerItem?._id == room?._id) {
              return {
                ...innerItem,
                leavedUsers: [...innerItem?.leavedUsers, user?._id],
              };
            }
            return innerItem;
          });
          return updatedRoomLastMessage;
        });
        if (selectedRoom?._id == room?._id) {
          setSelectedRoom(null);
        }
      }
    });
    // event edited from calendar socket
    socketConnection?.on("eventUpdated", ({ room }) => {
      if (room?._id == selectedRoom?._id) {
        setSelectedRoom(room);
      }
      setRoomsData((pre) => {
        const updatedRoomLastMessage = pre?.map((innerItem) => {
          if (innerItem?._id == room?._id) {
            return {
              ...innerItem,
              users: room?.users,
            };
          }
          return innerItem;
        });
        return updatedRoomLastMessage;
      });
    });

    return () => {
      socketConnection?.off("roomUpdated");
      socketConnection?.off("newRoom");
      socketConnection?.off("msg");
      socketConnection?.off("eventUpdated");
    };
  }, [selectedRoom]);
  // For Location Room
  useEffect(() => {
    if (roomDataFromLocation && typeof roomDataFromLocation == "object") {
      setSelectedRoom(roomDataFromLocation);
    }
  }, [roomDataFromLocation]);
  // start chat
  const startChat = async (params) => {
    const apiUrl = BaseURL(`chats/start`, "chat");
    return;
    setIsSending(true);
    const response = await Post(apiUrl, params, apiHeader(access_token));
    if (response !== undefined) {
      const { data } = response?.data;
      let tempRoomsData = [...roomsData];
      let roomAlreadyExist = tempRoomsData?.find(
        (item) => item?._id == data?._id
      );
      if (!roomAlreadyExist) {
        tempRoomsData = [data, ...roomsData];
      }
      setRoomsData(tempRoomsData);
      setSelectedRoom(data);
      setIsMessageModal(false);
      await getAllChats(1, data);
    }
    setIsSending(false);
  };
  // action click
  const handleActionClick = (flag) => {
    if (flag == "Info") {
    } else if (flag == "Add") {
      setAddMemberModal(true);
    }
  };
  // add member to chat
  const addMemberToChat = async (params) => {
    const apiUrl = BaseURL(`chats/update-users`, "chat");
    return;
    setAddMemberLoading(true);
    const response = await Patch(apiUrl, params, apiHeader(access_token));
    if (response !== undefined) {
      const { data } = response?.data;
      setSelectedRoom(data);
      setAddMemberModal(false);
    }
    setAddMemberLoading(false);
  };

  return (
    <SideBarSkeleton>
      <div className={classes.content}>
        <Row className={classes.contentRow}>
          {isMobile ? (
            selectedRoom == null ? (
              <Col>
                <RenderRoom
                  roomsData={roomsData}
                  roomsLoading={roomsLoading}
                  setSelectedRoom={setSelectedRoom}
                  selectedRoom={selectedRoom}
                  roomsPage={roomsPage}
                  roomsTotalCount={roomsTotalCount}
                  setRoomsPage={setRoomsPage}
                  setSearch={setSearch}
                  search={search}
                  setChatsPage={setChatsPage}
                  setChatsData={setChatsData}
                  setRoomsData={setRoomsData}
                  setIsMessageModal={setIsMessageModal}
                  getAllRooms={getAllRooms}
                  filter={filter}
                  setFilter={setFilter}
                />
              </Col>
            ) : (
              <Col>
                <RenderChats
                  selectedRoom={selectedRoom}
                  chatsData={chatsData}
                  chatsLoading={chatsLoading}
                  chatsPage={chatsPage}
                  chatsTotalCount={chatsTotalCount}
                  setChatsPage={setChatsPage}
                  isMobile={isMobile}
                  sendMsg={sendMsg}
                  scrollToBottom={scrollToBottom}
                  msgEndRef={msgEndRef}
                  getAllChats={getAllChats}
                  setSelectedRoom={setSelectedRoom}
                  handleToggle={handleToggle}
                  anchorRef={anchorRef}
                  roomsData={roomsData}
                  setRoomsData={setRoomsData}
                />
              </Col>
            )
          ) : (
            <>
              <Col lg={4}>
                <RenderRoom
                  roomsData={roomsData}
                  roomsLoading={roomsLoading}
                  setSelectedRoom={setSelectedRoom}
                  selectedRoom={selectedRoom}
                  roomsPage={roomsPage}
                  roomsTotalCount={roomsTotalCount}
                  setRoomsPage={setRoomsPage}
                  setSearch={setSearch}
                  search={search}
                  setChatsPage={setChatsPage}
                  setChatsData={setChatsData}
                  setRoomsData={setRoomsData}
                  setIsMessageModal={setIsMessageModal}
                  getAllRooms={getAllRooms}
                  filter={filter}
                  setFilter={setFilter}
                />
              </Col>
              <Col lg={8}>
                {selectedRoom ? (
                  <RenderChats
                    selectedRoom={selectedRoom}
                    chatsData={chatsData}
                    chatsLoading={chatsLoading}
                    chatsPage={chatsPage}
                    chatsTotalCount={chatsTotalCount}
                    setChatsPage={setChatsPage}
                    isMobile={isMobile}
                    sendMsg={sendMsg}
                    scrollToBottom={scrollToBottom}
                    msgEndRef={msgEndRef}
                    getAllChats={getAllChats}
                    handleToggle={handleToggle}
                    anchorRef={anchorRef}
                    setSelectedRoom={setSelectedRoom}
                    roomsData={roomsData}
                    setRoomsData={setRoomsData}
                  />
                ) : (
                  <div className={classes.chat_main}>
                    <NoData text="No Room Selected" />
                  </div>
                )}
              </Col>
            </>
          )}
        </Row>
      </div>
      {isMessageModal && (
        <SendMessageModal
          show={isMessageModal}
          setShow={setIsMessageModal}
          isLoading={isSending}
          handleClick={startChat}
          allAgents={allAgents}
        />
      )}
      {addMemberModal && (
        <AddMemberModal
          show={addMemberModal}
          setShow={setAddMemberModal}
          isLoading={addMemberLoading}
          handleClick={addMemberToChat}
          selectedRoom={selectedRoom}
          allAgents={allAgents}
        />
      )}
      <PoperComponent
        handleClick={handleActionClick}
        open={openPopper}
        setOpen={setOpenPopper}
        anchorRef={anchorRef}
        data={["Info", "Add"]}
        className={classes.poperComponent}
      />
    </SideBarSkeleton>
  );
}
