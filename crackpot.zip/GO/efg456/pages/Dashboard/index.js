import React, { useEffect, useState } from "react";
import { Col, Row } from "react-bootstrap";
import { DropDown } from "../../Component/DropDown/DropDown";
import PieOverview from "../../Component/PieOverview";
import ProductsCard from "../../Component/ProductsCard";
import ReChart from "../../Component/Recharts";
import SearchInput from "../../Component/SearchInput";
import SidebarSkeleton from "../../Component/SideBarSkeleton";
import { AllCardData, graphData } from "../../config/DummyData";
import { apiHeader, intToFloat } from "../../config/apiUrl";
import classes from "./Dashboard.module.css";
import { Get } from "../../Axios/AxiosFunctions";
import { useSelector } from "react-redux";
const data1 = [
  { name: "Group A", value: 50 },
  { name: "Group B", value: 35 },
  { name: "Group C", value: 15 },
];
const data2 = [
  { name: "Group A", value: 500 },
  { name: "Group B", value: 150 },
  { name: "Group C", value: 200 },
  { name: "Group D", value: 80 },
  { name: "Group E", value: 70 },
];

const Dashboard = () => {
  const [Filter, setFilter] = useState("");
  const filter = [{ label: "All", value: "all" }];
  const [search, setSearch] = useState("");
  const [data, setData] = useState(null);
  const [isApiCall, setIsApiCall] = useState(false);
  const { access_token } = useSelector((state) => state?.authReducer);

  const getData = async () => {
    const apiUrl = "";
    setIsApiCall(true);
    const response = await Get(apiUrl, apiHeader(access_token));
    if (response !== undefined) {
      setData(response?.data?.data);
    }
    setIsApiCall(false);
  };

  useEffect(() => {
    // getData();
  }, []);

  return (
    <SidebarSkeleton>
      <div className={classes.main}>
        <h2 className={classes.heading}>Dashboard</h2>
        <div className={classes.chart}>
          <div className={classes.header}>
            <h4>Total Earning This Year</h4>
            <p>${intToFloat(21233, 2)}</p>
          </div>
          <div>
            <ReChart data={graphData} />
          </div>
        </div>
        <Row>
          <Col lg={6} md={6} sm={12}>
            <div className={classes.pieContainer}>
              <PieOverview data={data1} />
            </div>
          </Col>
          <Col lg={6} md={6} sm={12}>
            <div className={classes.pieContainer}>
              <PieOverview data={data2} />
            </div>
          </Col>
        </Row>
        <div>
          <div className={classes.recentProducts}>
            <div className={classes.recentHeader}>
              <h2 className={classes.heading}>Recent Products</h2>
              <div className={classes.search}>
                <div className={classes.searchInput}>
                  <SearchInput
                    value={search}
                    setter={setSearch}
                    backgroundColor={"var(--white-color)"}
                    customStyle={{
                      width: "100%",
                    }}
                  />
                </div>
                <div className={classes.dropContainer}>
                  <DropDown
                    placeholder={"Filter"}
                    value={Filter}
                    setter={setFilter}
                    options={filter}
                    style={{
                      minHeight: "56px",
                      borderRadius: "10px",
                      boxShadow: "var(--card-shadow)",
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
          <Row>
            {AllCardData.map((item, index) => {
              return (
                <Col lg={4}>
                  <ProductsCard item={item} index={index} />
                </Col>
              );
            })}
          </Row>
        </div>
      </div>
    </SidebarSkeleton>
  );
};

export default Dashboard;
