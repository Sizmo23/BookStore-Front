import React, { useState } from "react";
import { Col, Row } from "react-bootstrap";
import { FiPlusCircle } from "react-icons/fi";
import { IoChevronBackOutline } from "react-icons/io5";
import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { Post, Put } from "../../Axios/AxiosFunctions";
import AddSubCategory from "../../Component/AddSubCategory";
import { Button } from "../../Component/Button/Button";
import EditSubCategory from "../../Component/EditSubCategory";
import { Input } from "../../Component/Input";
import SideBarSkeleton from "../../Component/SideBarSkeleton";
import {
  apiHeader,
  BaseURL,
  CreateFormData,
  formRegEx,
  formRegExReplacer,
} from "../../config/apiUrl";
import classes from "./AddProductCategory.module.css";
import MultiFileUpload from "../../Component/MultiFileUpload";

function AddProductCategory() {
  const category = useLocation().state?.category;
  const { allCategories } = useSelector((state) => state?.commonReducer);
  const { access_token } = useSelector((state) => state?.authReducer);
  const navigate = useNavigate();
  const [products, setProducts] = useState([
    { productName: "", productUnitId: null },
  ]);
  const [image, setImage] = useState(category?.image ? [category?.image] : []);
  const [categoryName, setCategoryName] = useState(
    category?.productCategoryName || ""
  );
  const [loading, setLoading] = useState(false);

  const handleAddCategory = async () => {
    const body = {
      productCategoryName: categoryName,
      ...(category
        ? { id: category?.id }
        : {
            products: products?.map((item) => ({
              ...item,
              productUnitId: item?.productUnitId?.id,
            })),
          }),
      image: Array.isArray(image) ? image[0] : image,
    };
    for (const key in body) {
      if (!body[key]) {
        return toast.error(
          `${key.replace(formRegEx, formRegExReplacer)} cannot be empty`
        );
      }
      if (key === "products") {
        if (body[key].length === 0) {
          return toast.error(`Enter Sub Categories`);
        }
        for (let i = 0; i < body[key].length; i++) {
          if (!body[key][i].productName) {
            return toast.error(`Enter Sub Category Name`);
          }
          if (!body[key][i].productUnitId) {
            return toast.error(`Select Sub Category Unit`);
          }
        }
      }
    }
    const formData = new FormData();
    for (let key in body) {
      if (key === "products") {
        for (let i = 0; i < body[key].length; i++) {
          formData.append(
            `products[${i}].productName`,
            body[key][i].productName
          );
          formData.append(
            `products[${i}].productUnitId`,
            body[key][i].productUnitId
          );
        }
      } else {
        formData.append(key, body[key]);
      }
    }
    const url = BaseURL(`ProductCategory`);
    setLoading("submitLoading");
    const response = category
      ? await Put(url, formData, apiHeader(access_token))
      : await Post(url, formData, apiHeader(access_token));
    if (response !== undefined) {
      toast.success(`Category ${category ? "updated" : "added"} successfully`);
      navigate("/categories");
    }
    setLoading(false);
  };

  return (
    <SideBarSkeleton>
      <div className={classes.pageMain}>
        <div className={classes.header}>
          <div
            className={classes.icon}
            onClick={() => {
              navigate(-1);
            }}
          >
            <IoChevronBackOutline />
          </div>
          <h1>{category ? "Edit" : "Add"} Category</h1>
        </div>

        <>
          <div className={classes.form}>
            <Row>
              <Col md={12}>
                <div className={classes.field}>
                  <Input
                    setter={setCategoryName}
                    value={categoryName}
                    label={"Category Name"}
                    placeholder={"Enter category name"}
                  />
                </div>
              </Col>
              <Col md={12}>
                <div className={classes.subCategoryList}>
                  {category ? (
                    <EditSubCategory
                      products={products}
                      setProducts={setProducts}
                      category={category}
                    />
                  ) : (
                    <AddSubCategory
                      products={products}
                      setProducts={setProducts}
                    />
                  )}
                </div>
              </Col>
              <Col md={12}>
                <MultiFileUpload
                  files={image}
                  setFiles={(e) => {
                    if (e.length > 1) {
                      return toast.error("Only one image is allowed");
                    }
                    setImage(e);
                  }}
                  acceptTypes={{ "image/*": [".png", ".jpeg", ".jpg"] }}
                  label="Category Image"
                  maxFiles={1}
                />
              </Col>
            </Row>
          </div>
          <div className={classes.fieldBtn}>
            <Button
              leftIcon={
                <FiPlusCircle size={20} color={"var(--accent-color)"} />
              }
              label={loading === "submitLoading" ? "Submitting..." : "Submit"}
              disabled={loading}
              onClick={handleAddCategory}
            />
          </div>
        </>
      </div>
    </SideBarSkeleton>
  );
}

export default AddProductCategory;
