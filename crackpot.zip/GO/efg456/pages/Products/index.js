import { useEffect, useRef, useState } from "react";
import { FiEye, FiTrash } from "react-icons/fi";
import { SlOptions } from "react-icons/sl";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { Delete, Get, Put } from "../../Axios/AxiosFunctions";
import { DropDown } from "../../Component/DropDown/DropDown";
import PopperComponent from "../../Component/PopperComponent";
import SearchInput from "../../Component/SearchInput";
import SideBarSkeleton from "../../Component/SideBarSkeleton";
import TableStructure from "../../Component/TableStructure";
import TabsComponent from "../../Component/TabsComponent";
import { BaseURL, apiHeader, recordsLimit } from "../../config/apiUrl";
import {
  defaultCategory,
  ProductsFilterOptions,
  ProductsTabsOptions,
} from "../../config/AppData";
import { productsData } from "../../config/DummyData";
import useDebounce from "../../CustomHooks/useDebounce";
import classes from "./Products.module.css";
import { corn } from "../../constant/imagePath";
import { FaCheck } from "react-icons/fa";
import { RxCross1 } from "react-icons/rx";
import AreYouSureModal from "../../modals/AreYouSureModal";
import { toast } from "react-toastify";
const deafult = {
  label: defaultCategory?.productCategoryName,
  value: defaultCategory?.id,
  image: defaultCategory?.image,
};
const Products = () => {
  const ref = useRef(null);
  const { access_token } = useSelector((state) => state?.authReducer);
  const [selectedItem, setSelectedItem] = useState(null);
  const [search, setSearch] = useState("");
  const [indexRef, setIndexRef] = useState(null);
  const debounce = useDebounce(search, 500);
  const [popper, setPopper] = useState(false);
  const [loading, setLoading] = useState(false);
  const [totalCount, setTotalCount] = useState(30);
  const [filterValue, setFilterValue] = useState(ProductsFilterOptions[0]);
  const [category, setCategory] = useState(deafult);
  const [page, setPage] = useState(1);
  const [data, setData] = useState(productsData);
  const [categories, setCategories] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const popperHandler = (item, index) => {
    setSelectedItem(item);
    setIndexRef(index);
    setTimeout(() => {
      setPopper((prev) => !prev);
    }, 300);
  };
  const getData = async (
    pageNo = page,
    filter = filterValue?.value,
    categoryValue = category?.value
  ) => {
    console.log(filter, "filter");
    const query = {
      PageNumber: pageNo,
      ...(categoryValue && { ProductCategoryId: categoryValue || "" }),
      PageSize: recordsLimit,
      // text: debounce,
      IsEnabled: filter,
    };
    const apiUrl = BaseURL(
      `VendorProducts/all?${new URLSearchParams(query).toString()}`
    );
    setLoading("mainLoading");
    const response = await Get(apiUrl, access_token);
    if (response !== undefined) {
      setData(response?.data?.data);
      setTotalCount(response?.data?.totalItems);
    } else {
      setData([]);
      setTotalCount(0);
    }
    setLoading(false);
  };
  const getCategories = async () => {
    const apiUrl = BaseURL(`ProductCategorys/master`);
    setLoading("mainLoading");
    const response = await Get(apiUrl, access_token);
    if (response !== undefined) {
      const { data } = response?.data;
      setCategories([defaultCategory, ...data]);
    }
    setLoading(false);
  };
  const handleChangeStatus = async () => {
    const params = {
      id: selectedItem?.id,
      isEnabled: !selectedItem?.isEnabled,
    };
    const apiUrl = BaseURL(`VendorProduct/status`);
    setLoading("statusLoading");
    const response = await Put(apiUrl, params, apiHeader(access_token));
    if (response !== undefined) {
      await getData(page);
      toast.success("Product status updated successfully");
      setModalOpen(false);
    }
    setLoading(false);
  };
  const handleDelete = async () => {
    const apiUrl = BaseURL(`VendorProduct?id=${selectedItem?.id}`);
    setLoading("deleteLoading");
    const response = await Delete(apiUrl, apiHeader(access_token));
    if (response !== undefined) {
      setSelectedItem(null);
      setData(data?.filter((item) => item?.id !== selectedItem?.id));
      setModalOpen(false);
      toast.success("Product deleted successfully");
    }
    setLoading(false);
  };
  const popperActionHandler = (option) => {
    if (option?.value == "Delete") {
      setModalOpen("delete");
    } else if (option?.value == "View") {
    } else {
      setModalOpen("status");
    }
  };

  useEffect(() => {
    setPage(1);
    getData(1);
  }, [debounce]);
  useEffect(() => {
    getCategories();
  }, []);
  console.log(category);
  return (
    <SideBarSkeleton>
      <div className={classes.container}>
        <div className={classes.header}>
          <h1>Products</h1>{" "}
        </div>

        <div className={classes.tabSection}>
          <div className={classes.tabs}>
            <TabsComponent
              data={categories?.map((ele) => {
                return {
                  image: ele?.image,
                  label: ele?.productCategoryName,
                  value: ele?.id,
                };
              })}
              value={category}
              onClick={(e) => {
                setPage(1);
                setCategory(e);
                getData(1, filterValue?.value, e?.value);
              }}
            />
          </div>
          <div className={classes.searchSection}>
            <SearchInput
              setter={setSearch}
              value={search}
              customStyle={{ height: "53px" }}
            />
            <DropDown
              options={ProductsFilterOptions}
              value={filterValue}
              setter={(e) => {
                setPage(1);
                setFilterValue(e);
                getData(1, e?.value, category?.value);
              }}
              customStyle={{ height: "53px" }}
            />
          </div>
        </div>
        <TableStructure
          headerHandlers={false}
          // ProductsFilterOptions={ProductsFilterOptions}
          // filter={filter}
          // setFilterValue={setFilterValue}
          page={page}
          // isSearch
          // setSearch={(e) => {
          //   setPage(1);
          //   setSearch(e);
          //   // getData(1, e);
          // }}
          totalRecord={totalCount}
          noDataMessage="No Products Found"
          isLoading={loading === "mainLoading"}
          setPage={(e) => {
            setPage(e);
            // getData(e, filter?.value, category?.value);
          }}
          // headerTitle={
          //   <TabsComponent
          //     customClass={classes._tabs}
          //     data={ProductsTabsOptions}
          //     value={category}
          //     onClick={setCategory}
          //   />
          // }
          headerTitle={false}
          tableHeaders={[
            {
              label: "Product ID",
              value: "id",
            },
            {
              label: "Product Name",
              value: "productName",
            },
            {
              label: "Product Category",
              value: "productCategoryName",
            },
            {
              label: "Status",
              value: "status",
            },
            {
              label: "Actions",
              value: "action",
              headerStyle: { textAlign: "center" },
              dataStyle: { textAlign: "center" },
            },
          ]}
          tableContent={data?.map((ele, index) => ({
            ...ele,
            status: ele?.isEnabled ? "Active" : "Inactive",
            action: (
              <span
                ref={indexRef === index ? ref : null}
                onClick={() => popperHandler(ele, index)}
              >
                <SlOptions color="var(--main-color)" cursor="pointer" />
              </span>
            ),
          }))}
          customStyle={{ height: "calc(100vh - 350px)" }}
        />
      </div>
      <PopperComponent
        anchorRef={ref}
        data={popperOptions?.filter((item) => {
          if (["Active", "Inactive"].includes(item.value)) {
            return item.label !== selectedItem?.isEnabled;
          }
          return item;
        })}
        open={popper}
        handleClick={popperActionHandler}
        setOpen={setPopper}
      />
      {modalOpen === "delete" && (
        <AreYouSureModal
          show={modalOpen}
          setShow={setModalOpen}
          onClick={handleDelete}
          isApiCall={loading === "deleteLoading"}
          title="Are you sure?"
          subTitle="You want to delete this product?"
        />
      )}
      {modalOpen === "status" && (
        <AreYouSureModal
          show={modalOpen}
          setShow={setModalOpen}
          onClick={handleChangeStatus}
          isApiCall={loading === "statusLoading"}
          title="Are you sure?"
          subTitle={`You want to change the status of ${
            selectedItem?.productName
          } to ${selectedItem?.isEnabled ? "Inactive" : "Active"}`}
        />
      )}
    </SideBarSkeleton>
  );
};

export default Products;
const popperOptions = [
  {
    icon: <FiEye />,
    label: "View",
    value: "View",
  },
  {
    icon: <FaCheck />,
    label: true,
    value: "Active",
  },
  {
    icon: <RxCross1 />,
    label: false,
    value: "Inactive",
  },
  {
    icon: <FiTrash />,
    label: "Delete",
    value: "Delete",
  },
];
