import React, { useEffect, useState } from "react";
import classes from "./Commission.module.css";
import { Input } from "../../Component/Input";
import SidebarSkeleton from "../../Component/SideBarSkeleton";
import { Button } from "../../Component/Button/Button";
import { FaEdit, FaPercentage } from "react-icons/fa";
import { toast } from "react-toastify";
import { Get, Put } from "../../Axios/AxiosFunctions";
import { BaseURL, apiHeader } from "../../config/apiUrl";
import { useSelector } from "react-redux";
import { Loader } from "../../Component/Loader";
const Commission = () => {
  const { access_token } = useSelector((state) => state.authReducer);
  const [commission, setCommission] = useState("");
  // const formattedCommission = parseFloat(commission).toFixed(2);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!commission) {
      toast.error("Please enter commission");
      return;
    }
    if (Number(commission) > 100) {
      toast.error("Commission should be less than 100");
      return;
    }
    setLoading("update");
    const response = await Put(
      BaseURL(`Commission?percentage=${commission}`),
      {  },
      apiHeader(access_token)
    );
    if (response !== undefined) {
      toast.success("Commission updated successfully");
      getData()
    }
    setLoading(false);
  };
  const getData = async () => {
    setLoading("main");
    const response = await Get(BaseURL(`Commission`), access_token);
    if (response !== undefined) {
      setCommission(response?.data?.data?.percentage);
    }
    setLoading(false);
  };
  useEffect(() => {
    getData();
  }, []);
  return (
    <SidebarSkeleton>
      <div className={classes.container}>
        <h2 className={classes.heading}>Add Commission</h2>
        {loading === "main" ? (
          <Loader />
        ) : (
          <div className={classes.form}>
            <Input
              regexType={"number"}
              label={"Commission (Percentage)"}
              setter={setCommission}
              value={commission}
              placeholder={"00"}
              customStyle={{ width: "50%" }}
              rightIcon={
                <FaPercentage color="var(--secondary-color)" size={15} />
              }
            />
            <div className={classes.butt}>
              <Button
                leftIcon={<FaEdit color="var(--accent-color)" size={15} />}
                label={loading === "update" ? "Updating..." : "Update"}
                disabled={loading === "update"}
                // customStyle={{ padding: "20px 37px" }}
                onClick={handleSubmit}
              />
            </div>
          </div>
        )}
      </div>
    </SidebarSkeleton>
  );
};

export default Commission;
