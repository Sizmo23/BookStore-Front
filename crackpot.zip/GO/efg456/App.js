import "bootstrap/dist/css/bootstrap.min.css";
import "font-awesome/css/font-awesome.min.css";
import "react-modern-drawer/dist/index.css";
import "react-quill/dist/quill.snow.css";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "react-toastify/dist/ReactToastify.min.css";
import "./assets/Styles/style.css";
import "./assets/Styles/table.css";
import "react-phone-number-input/style.css";

import React, { Suspense, lazy, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import { Get } from "./Axios/AxiosFunctions";
import { Loader } from "./Component/Loader";
import BeforeLoginRoute from "./Helper/BeforeLoginRoute";
import ProtectedRoute from "./Helper/ProtectedRoute";
import ScrollToTop from "./Helper/ScrollToTop";
import { BaseURL } from "./config/apiUrl";
import { updateUser } from "./store/auth/authSlice";
import {
  saveCategories,
  saveProductQuality,
  saveProductUnits,
} from "./store/common/commonSlice";

const NotFound = lazy(() => import("./pages/NotFound"));
const Login = lazy(() => import("./pages/Login"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const Chat = lazy(() => import("./pages/Chat"));
const Products = lazy(() => import("./pages/Products"));
const Orders = lazy(() => import("./pages/Orders"));
const AddEditProductCategory = lazy(() => import("./pages/AddProductCategory"));
const EWallet = lazy(() => import("./pages/EWallet"));
const UserManagement = lazy(() => import("./pages/user-management"));
const Commission = lazy(() => import("./pages/Commission"));
const Settings = lazy(() => import("./pages/Setting"));
const Categories = lazy(() => import("./pages/Categories"));
const CategoryDetails = lazy(() =>
  import("./pages/Categories/CategoryDetails")
);
const OrderDetails = lazy(() => import("./pages/ViewOrder"));

function App() {
  const [isLoading, setIsLoading] = useState(false);
  const { access_token } = useSelector((state) => state?.authReducer);
  const { isLogin } = useSelector((state) => state?.authReducer);

  const dispatch = useDispatch();

  const getPublicData = async () => {
    const unitsUrl = BaseURL("ProductUnits");
    const qualityUrl = BaseURL("ProductQualitys");
    const userUrl = BaseURL("User");
    setIsLoading(true);
    const [unitRes, qualityRes, useRes] = await Promise.allSettled([
      Get(unitsUrl, access_token, false),
      Get(qualityUrl, access_token, false),
      Get(userUrl, access_token, false, dispatch),
    ]);
    if (unitRes?.value || qualityRes?.value || useRes?.value) {
      dispatch(saveProductUnits(unitRes?.value?.data?.data));
      dispatch(saveProductQuality(qualityRes?.value?.data?.data));
      dispatch(updateUser(useRes?.value?.data?.data));
    }
    setIsLoading(false);
  };
  useEffect(() => {
    if (isLogin) {
      getPublicData();
    }
  }, [isLogin]);

  if (isLoading) {
    return <Loader className="vh-100" />;
  }

  return (
    <>
      <ToastContainer />
      <BrowserRouter>
        <ScrollToTop />
        <Suspense fallback={<Loader className={"vh-100"} />}>
          <Routes>
            <Route
              path="/login"
              exact
              element={<BeforeLoginRoute element={<Login />} />}
            />
            <Route
              path="/"
              exact
              element={<ProtectedRoute element={<Dashboard />} />}
            />
            <Route
              path="/products"
              exact
              element={<ProtectedRoute element={<Products />} />}
            />
            <Route
              path="/orders"
              exact
              element={<ProtectedRoute element={<Orders />} />}
            />
            <Route
              path="/orders/:id"
              exact
              element={<ProtectedRoute element={<OrderDetails />} />}
            />
            <Route
              path="/e-wallet"
              exact
              element={<ProtectedRoute element={<EWallet />} />}
            />
            <Route
              path="/chat"
              exact
              element={<ProtectedRoute element={<Chat />} />}
            />
            <Route
              path="/add-edit-category"
              exact
              element={<ProtectedRoute element={<AddEditProductCategory />} />}
            />
            <Route
              path="/user-management"
              exact
              element={<ProtectedRoute element={<UserManagement />} />}
            />
            <Route
              path="/commission"
              exact
              element={<ProtectedRoute element={<Commission />} />}
            />
            <Route
              path="/categories"
              exact
              element={<ProtectedRoute element={<Categories />} />}
            />
            <Route
              path="/category-detail"
              exact
              element={<ProtectedRoute element={<CategoryDetails />} />}
            />
            <Route
              path="/setting"
              exact
              element={<ProtectedRoute element={<Settings />} />}
            />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
      </BrowserRouter>
    </>
  );
}

export default App;
