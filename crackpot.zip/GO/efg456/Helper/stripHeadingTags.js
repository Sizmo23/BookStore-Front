export function StripHeadingTags(str) {
  let stripedStr = str;
  if (str !== "") {
    stripedStr = str?.replace(/<\/?h[1-6][^>]*>/g, "");
  }
  return stripedStr;
}
