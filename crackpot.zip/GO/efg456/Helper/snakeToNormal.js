export const snakeToNormal = (str) => {
  if (str === undefined || str === null) {
    return;
  }
  return str
    .split("-")
    .map((e) => `${e?.[0].toUpperCase()}${e?.slice(1, e?.length)}`)
    .join(" ");
};
