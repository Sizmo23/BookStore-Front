export function stripAllHtmlTags(input) {
  return input.replace(/<[^>]*>?/gm, "");
}
