import moment from "moment";
import classes from "./NotificationCard.module.css";
import { FaUser } from "react-icons/fa";


const NotificationCard = ({ data }) => {
  return (
    <div className={classes.notification}>
      <div className={classes.description}>
        <div className={classes.userProfile}>
          <div className={classes.imageBox}>
            {/* <img src={data?.sender?.photo} alt="" /> */}
            <FaUser size={12} color="var(--white-color)" />
          </div>
          <div className={classes.info}>
            <h5>{data?.sender?.fullName}</h5>
            <p>{data?.message}</p>
          </div>
        </div>
      </div>
      <div className={classes.createdDate}>
        <div className={classes.status} />
        <p>{moment(data?.createdAt).fromNow() }</p>
      </div>
    </div>
  );
};

export default NotificationCard;
