import classes from "./TabsComponent.module.css";

function TabsComponent({ data, value, onClick }) {
  return (
    <div className={classes.tabs}>
      <div className={classes._tabsHeading}>
        {data?.map((ele, index) => (
          <div
            className={`${classes._initialTab} ${
              value?.value === ele?.value ? classes._selectedclass : ""
            } `}
            onClick={() => onClick(ele)}
            key={index}
          >
            {ele?.image ? (
              <img src={ele?.image} className={classes.icon_image} />
            ) : (
              <span>{ele?.icon}</span>
            )}
            <p> {ele?.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default TabsComponent;
