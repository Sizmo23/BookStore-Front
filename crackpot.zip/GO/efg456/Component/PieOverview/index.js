import React, { useState } from "react";
import classes from "./PieOverview.module.css";
import { Col, Row } from "react-bootstrap";
import { GoDotFill } from "react-icons/go";
import PieCharts from "../PieCharts";
import { DropDown } from "../DropDown/DropDown";

const PieOverview = ({ data }) => {
  const COLORS = ["#B2DB4F", "#FEA918", "#FFF830", "#D86245", "#4D3617"];
  const filter = [{ label: "All", value: "all" }];
  const [Filter, setFilter] = useState("");
  return (
    <>
      <div className={classes.walletSummary}>
        <h6 className={classes.heading}>Pie Graph</h6>
        <div className={classes.dropContainer}>
          <DropDown
            placeholder={"Filter"}
            isSearchable={false}
            value={Filter}
            setter={setFilter}
            options={filter}
            indicatorColor="var(--white-color"
            placeholderColor="var(--white-color)"
            customStyle={{
              backgroundColor: "var(--secondary-color)",
              color: "var(--white-color) !important",
              borderRadius: "10px",
              // padding: "3px 3px 3px 8px",
            }}
          />
        </div>
      </div>

      <Row className={classes.row}>
        <Col lg={5} className={classes.alignCenter}>
          <div className={classes.chartDiv}>
            <PieCharts data={data} />
            {/* abd */}
          </div>{" "}
        </Col>
        <Col lg={7}>
          <div className={classes.chartContainer}>
            {data?.map((dataset, index) => [
              <div key={`chart-${index}`} className={classes.chart}>
                <div className={classes.icon}>
                  <GoDotFill size={22} color={COLORS[index % COLORS.length]} />
                  <h6>{`Dataset ${index + 1}`}</h6>
                </div>
                <p>0000</p>
              </div>,
              <hr key={`hr-${index}`} className={classes.hr1} />,
            ])}
          </div>
        </Col>
      </Row>
    </>
  );
};

export default PieOverview;
