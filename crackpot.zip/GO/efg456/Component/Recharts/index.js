import classes from "./Recharts.module.css";
import React, { PureComponent } from "react";
import { graphData } from "../../config/DummyData";
import { projectData } from "../../config/DummyData";
import { pieData } from "../../config/DummyData";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  CartesianGrid,
  Bar,
  PieChart,
  Pie,
  Cell,
  Label,
} from "recharts";

export default function ReChart({ data }) {
  // const data = [
  //   { name: "Group A", value: 500 },
  //   { name: "Group B", value: 150 },
  //   { name: "Group C", value: 200 },
  //   { name: "Group D", value: 80 },
  //   { name: "Group E", value: 70 },
  // ];
  // const COLORS = ["#FF7555", "#FFE934", "#FF92E7", "#AA16A3", "#FFDB80"];

  return (
    <>
      {/* <ResponsiveContainer width="100%" height={320}>
        <PieChart width="100%" height={320}>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius="75%"
            outerRadius="100%"
            fill="#8884d8"
            paddingAngle={0}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={COLORS[index % COLORS.length]}
              />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer> */}

      <ResponsiveContainer width="100%" height={320}>
        <BarChart
          width="100%"
          height={320}
          data={data}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid
            vertical={false}
            horizontal={true}
            strokeDasharray="0 0"
            fillOpacity={0.1}
          />
          <XAxis
            dataKey="name"
            axisLine={false}
            tickLine={false}
            tick={{ stroke: "#254B18", strokeWidth: 0 }}
            // tickSize={1}
          />
          <YAxis
            axisLine={false}
            tickLine={false}
            dataKey="uv"
            tick={{ stroke: "#254B18", strokeWidth: 1 }}
          />

          <Bar
            dataKey="uv"
            fill="#82ca9d"
            barSize={10}
            radius={[20, 20, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>
    </>
  );
}
