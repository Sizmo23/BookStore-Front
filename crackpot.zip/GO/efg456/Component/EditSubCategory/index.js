import React, { useEffect, useState } from "react";
import classes from "./EditSubCategory.module.css";
import { FiPlusCircle } from "react-icons/fi";
import { Button } from "../Button/Button";
import { MdDelete, MdEdit } from "react-icons/md";
import { toast } from "react-toastify";
import { Input } from "../Input";
import { DropDown } from "../DropDown/DropDown";
import { useSelector } from "react-redux";
import { Delete, Get, Post, Put } from "../../Axios/AxiosFunctions";
import {
  apiHeader,
  BaseURL,
  formRegEx,
  formRegExReplacer,
} from "../../config/apiUrl";
import { FaCheck, FaRegSave } from "react-icons/fa";
import { Loader } from "../Loader";
import { Spinner } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
const EditSubCategory = ({
  products,
  setProducts,
  addMultiple = true,
  heading = "Sub Categories",
  category,
}) => {
  const navigate = useNavigate();
  const { access_token } = useSelector((state) => state?.authReducer);
  const { productUnits } = useSelector((state) => state?.commonReducer);
  const [isLoading, setIsLoading] = useState(false);
  const getData = async (updateObj, loader = "mainLoading") => {
    const apiUrl = BaseURL(
      `Products?productCategoryId=${category?.id}`
    );
    setIsLoading(loader);
    const response = await Get(apiUrl, access_token);
    if (response !== undefined) {
      const sub_categories = response?.data?.data?.map((item) => ({
        productName: item?.productName,
        productUnitId: productUnits?.find(
          (ele) => ele?.id === item?.productUnitId
        ),
        productId: item?.productId,
      }));
      if (updateObj) {
        sub_categories.push(updateObj);
      }
      setProducts(sub_categories);
    }
    setIsLoading(false);
  };
  const handleAddEdit = async (params) => {
    const body = {
      productName: params?.productName,
      productUnitId: params?.productUnitId?.id || params?.productUnitId,
      ...(params?.productId
        ? { id: params?.productId }
        : { productCategoryId: category?.id }),
    };
    for (const key in body) {
      if (!body[key]) {
        return toast.error(
          `Please fill ${key
            .replace(formRegEx, formRegExReplacer)
            .toLowerCase()}`
        );
      }
    }
    const loader = params?.productId || "addLoading";
    const apiUrl = BaseURL("Product");
    setIsLoading(loader);
    const response = params?.productId
      ? await Put(apiUrl, body, apiHeader(access_token))
      : await Post(apiUrl, body, apiHeader(access_token));
    if (response) {
      toast.success(
        `${
          params?.productId ? "Sub Category Updated" : "Sub Category Added"
        } Successfully`
      );
      const updateObj = params?.productId
        ? products?.find((item) => !item?.productId)
        : null;
      getData(updateObj, loader);
    }
    setIsLoading(false);
  };
  const handleDelete = async (id) => {
    const apiUrl = BaseURL(`Product?id=${id}`);
    setIsLoading({ id });
    const response = await Delete(apiUrl, apiHeader(access_token));
    if (response) {
      toast.success("Sub Category Deleted Successfully");
      setProducts(products.filter((item) => item?.productId !== id));
    }
    setIsLoading(false);
  };
  useEffect(() => {
    if (category) {
      getData();
    } else {
      navigate(-1);
    }
  }, [category]);
  return (
    <>
      <div className={classes.__header}>
        <p className={classes.__title}>{heading}</p>
        {addMultiple && (
          <Button
            leftIcon={<FiPlusCircle size={12} color={"var(--accent-color)"} />}
            className={classes.addBtn}
            label={"Add"}
            onClick={() => {
              if (!products[products.length - 1]?.productId) {
                return toast.error(`Please fill the last sub category`);
              }
              setProducts((prev) => [
                ...prev,
                { productName: "", productUnitId: null, update: true },
              ]);
            }}
          />
        )}
      </div>
      {isLoading == "mainLoading" ? (
        <Loader />
      ) : (
        products?.map((item, index) => {
          const allowUpdate = item?.update;
          return (
            <div className={classes.subcategoryInput}>
              <Input
                value={item?.productName}
                setter={(value) => {
                  setProducts((prev) => {
                    const temp = [...prev];
                    temp[index].productName = value;
                    return temp;
                  });
                }}
                placeholder={"Enter Sub Category Name"}
                disabled={allowUpdate ? false : true}
              />
              <DropDown
                value={item?.productUnitId}
                setter={(value) =>
                  setProducts((prev) => {
                    const temp = [...prev];
                    temp[index].productUnitId = value;
                    return temp;
                  })
                }
                options={productUnits}
                placeholder={"Select Units"}
                isSearchable={false}
                optionValue={"id"}
                optionLabel={"unitName"}
                disabled={allowUpdate ? false : true}
              />
              {item?.productId ? (
                <div className={classes.actions}>
                  {!allowUpdate ? (
                    <div
                      className={[classes.crossIcon, classes.editIcon].join(
                        " "
                      )}
                      onClick={() => {
                        setProducts((prev) => {
                          return prev?.map((ele) => {
                            if (ele?.productId === item?.productId) {
                              return { ...ele, update: true };
                            }
                            return { ...ele, update: false };
                          });
                        });
                      }}
                    >
                      <MdEdit size={20} />
                    </div>
                  ) : (
                    <div
                      className={[classes.crossIcon, classes.saveIcon].join(
                        " "
                      )}
                      onClick={() => {
                        handleAddEdit(item);
                      }}
                    >
                      {" "}
                      {isLoading === item?.productId ? (
                        <Spinner size="sm" variant="light" />
                      ) : (
                        <FaRegSave size={20} />
                      )}
                    </div>
                  )}
                  {products?.length > 1 && (
                    <div
                      className={classes.crossIcon}
                      onClick={() => {
                        handleDelete(item?.productId);
                      }}
                    >
                      {isLoading?.id === item?.productId ? (
                        <Spinner size="sm" variant="light" />
                      ) : (
                        <MdDelete size={20} />
                      )}
                    </div>
                  )}
                </div>
              ) : (
                <div className={classes.actions}>
                  {!allowUpdate ? (
                    <div
                      className={[classes.crossIcon, classes.editIcon].join(
                        " "
                      )}
                      onClick={() => {
                        setProducts((prev) => {
                          return prev?.map((ele) => {
                            if (ele?.productId === item?.productId) {
                              return { ...ele, update: true };
                            }
                            return { ...ele, update: false };
                          });
                        });
                      }}
                    >
                      <MdEdit size={20} />
                    </div>
                  ) : (
                    <div
                      className={[classes.crossIcon, classes.saveIcon].join(
                        " "
                      )}
                      onClick={() => {
                        handleAddEdit(item);
                      }}
                    >
                      {isLoading === "addLoading" ? (
                        <Spinner size="sm" variant="light" />
                      ) : (
                        <FaCheck size={20} />
                      )}
                    </div>
                  )}
                  <div
                    className={classes.crossIcon}
                    onClick={() => {
                      setProducts((prev) => {
                        let temp = [...prev];
                        temp.splice(index, 1);
                        return temp;
                      });
                    }}
                  >
                    <MdDelete size={20} />
                  </div>
                </div>
              )}
            </div>
          );
        })
      )}
    </>
  );
};

export default EditSubCategory;
