import classes from "./Statuses.module.css";
export default function Statuses({ status }) {
  const statusesColor = {
    pending: {
      color: "#FFD500",
      label: "Pending",
      textColor: "var(--main-color)",
    },
    delivered: {
      color: "#6FBA43",
      label: "Delivered",
      textColor: "var(--white-color)",
    },
    disputed: {
      color: "#D86245",
      label: "Disputed",
      textColor: "var(--white-color)",
    },
    hold: {
      color: "#F89030",
      label: "Hold",
      textColor: "var(--white-color)",
    },
    active: {
      color: "#37CA37",
      label: "Active",
      textColor: "var(--white-color)",
    },
  };

  return (
    <div className={classes.statusWrapper}>
      <p
        style={{
          backgroundColor: statusesColor[status]?.color,
          color: statusesColor[status]?.textColor,
        }}
      >
        {statusesColor[status]?.label}
      </p>
    </div>
  );
}
