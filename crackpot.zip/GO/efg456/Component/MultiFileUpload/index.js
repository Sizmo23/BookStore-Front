import React, { useRef, useState } from "react";
import classes from "./MultiFileUpload.module.css";
import Dropzone from "react-dropzone";
import { IoCloseOutline } from "react-icons/io5";
import { Button } from "../Button/Button";
import ReactPlayer from "react-player";
import { BsFileEarmarkPdfFill } from "react-icons/bs";
import { AiFillEye, AiFillFileWord } from "react-icons/ai";
import { FiUpload } from "react-icons/fi";
import { toast } from "react-toastify";
import { imageUrl, mediaUrl } from "../../config/apiUrl";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import { Spinner } from "react-bootstrap";

const MultiFileUpload = ({
  label,
  files = [],
  setFiles,
  maxFiles = 10,
  acceptTypes = {
    "image/*": [".png", ".jpeg", ".jpg"],
    "video/*": [".mp4"],
    "application/pdf": [".pdf"],
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [
      ".docx",
    ],
  },
  text = "Drag and drop images here or click to select files",
  uploadBoxClass = "",
  noDrag,
  maxSize = 10000000,
  deletedFiles = [],
  setDeletedFiles,
  multiple = true,
  allowDrag = false,
  primaryImageStyle,
  uploading = false,
  disabled = false,
}) => {
  const [_noClick, _setNoClick] = useState(false);
  const sectionRef = useRef(null);
  const onDragEnd = (result) => {
    const { source, destination } = result;
    // If user tries to drop in an unknown destination
    if (!destination) return;

    // if the user drags and drops back in the same position
    if (destination.index === source.index) return;

    const temp = [...files];
    // let sourceRow = temp[source?.index];
    // let destinationRow = temp[destination?.index];
    // temp[source?.index] = destinationRow;
    // temp[destination?.index] = sourceRow;

    const [reorderedItem] = temp.splice(source.index, 1);
    temp.splice(destination.index, 0, reorderedItem);

    setFiles(temp);

    setTimeout(() => {
      _setNoClick(false);
    }, 1000);
  };
  return (
    <div
      className={
        allowDrag ? classes.fileInputDivWithDrag : classes.fileInputDiv
      }
    >
      {label && <label>{label}</label>}
      <Dropzone
        maxSize={maxSize}
        noClick={_noClick}
        noDrag={noDrag}
        accept={acceptTypes}
        maxFiles={maxFiles}
        multiple={multiple}
        disabled={disabled}
        onDrop={(acceptedFiles) => {
          setFiles([...files, ...acceptedFiles]);
          // scroll to end
          if (allowDrag && sectionRef?.current) {
            sectionRef?.current?.scrollIntoView({
              block: "nearest",
              behavior: "smooth",
            });
          }
        }}
        onDropRejected={(rejectedFiles) => {
          rejectFilesError(rejectedFiles, maxSize, maxFiles);
        }}
      >
        {({ getRootProps, getInputProps }) => (
          <section
            className={[
              classes.main,
              // files?.length > 0 &&
              allowDrag ? classes.isFiles : classes.withoutGridFiles,
              uploadBoxClass && uploadBoxClass,
            ].join(" ")}
            style={{ cursor: disabled ? "not-allowed" : "pointer" }}
            {...getRootProps()}
          >
            {/* {files?.length > 0 && (
              <button
                className={classes.uploadMoreBtn}
                style={{
                  cursor: disabled ? "not-allowed" : "pointer",
                }}
              >
                <FiUpload size={20} color={"#fff"} />
              </button>
            )} */}
            <input {...getInputProps()} />
            {files?.length === 0 ? (
              <div className={classes.section}>
                <div className={classes.fileUploadOptions}>
                  <FiUpload size={60} color={"#000000b5"} />
                  <p>{text}</p>
                </div>
              </div>
            ) : (
              <DragDropContext
                onDragEnd={onDragEnd}
                onDragStart={() => _setNoClick(true)}
              >
                <Droppable droppableId="droppable" direction="horizontal">
                  {(provided, snapshot) => (
                    <div
                      {...provided.droppableProps}
                      ref={provided.innerRef}
                      className={
                        allowDrag
                          ? classes.imagesWrap
                          : classes.withoutGridImagesWrap
                      }
                    >
                      {files?.map((item, index) => (
                        <Draggable
                          key={index.toString()}
                          draggableId={index.toString()}
                          index={index}
                          isDragDisabled={!allowDrag || typeof item == "object"}
                        >
                          {(provided, snapshot) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              {...provided.dragHandleProps}
                              style={{
                                ...provided.draggableProps.style,
                                ...(index === 0 ? primaryImageStyle : {}), // Your conditional style
                              }}
                              className={classes.image}
                            >
                              <Button
                                className={classes.closeIconBtn}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const newFiles = [...files];
                                  newFiles?.splice(index, 1);
                                  setFiles(newFiles);
                                  if (setDeletedFiles) {
                                    if (typeof item !== "object") {
                                      setDeletedFiles([...deletedFiles, item]);
                                    }
                                  }
                                }}
                                disabled={uploading || disabled}
                                customStyle={{
                                  cursor: disabled ? "not-allowed" : "pointer",
                                }}
                              >
                                <IoCloseOutline size={20} />
                              </Button>
                              {uploading && typeof item == "object" && (
                                <div className={classes.uploadingOverlay}>
                                  <Spinner animation="border" variant="white" />
                                </div>
                              )}
                              <RenderFileComponent item={item} />
                            </div>
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
              </DragDropContext>
            )}
            <div ref={sectionRef} />
          </section>
        )}
      </Dropzone>
    </div>
  );
};

export default MultiFileUpload;

const RenderFileComponent = ({ item }) => {
  return (
    <>
      {(
        typeof item == "object"
          ? item?.type?.split("/")[0] === "image"
          : ["jpg", "jpeg", "png", "jfif", "webp"]?.includes(
              item?.split(".")[item?.split(".")?.length - 1]
            )
      ) ? (
        <img
          src={typeof item == "string" ? item : URL.createObjectURL(item)}
          alt=""
          draggable="false"
        />
      ) : (
          typeof item == "object"
            ? item?.type?.split("/")[0] === "video"
            : ["mp4"]?.includes(item?.split(".")[item?.split(".")?.length - 1])
        ) ? (
        <ReactPlayer
          url={
            typeof item == "string" ? mediaUrl(item) : URL.createObjectURL(item)
          }
          playing={false}
          controls={true}
          width={"100%"}
          height={"100%"}
          className={classes.videoPlayer}
        />
      ) : (
          typeof item == "object"
            ? item?.type == "application/pdf"
            : ["pdf"]?.includes(item?.split(".")[item?.split(".")?.length - 1])
        ) ? (
        <div className={classes.pdfView}>
          <span
            onClick={(e) => {
              e.stopPropagation();
              window.open(
                typeof item == "string"
                  ? mediaUrl(item)
                  : URL.createObjectURL(item),
                "_blank"
              );
            }}
          >
            <AiFillEye
              color="var(--white-color)"
              size={22}
              style={{ cursor: "pointer" }}
            />
          </span>
          <div>
            <BsFileEarmarkPdfFill size={40} color={`#ff1300`} />
            <p>{typeof item == "string" ? item?.slice(7) : item?.name}</p>
          </div>
          {/* <iframe
            src={
              typeof item == "string"
                ? `https://2514-39-51-68-238.ngrok-free.app/api/v1/media/${item}`
                : URL.createObjectURL(item)
            }
            className={classes.pdfIframe}
            seamless="seamless"
            style={{
              overflow: "hidden",
            }}
          /> */}
        </div>
      ) : (
        (typeof item == "object"
          ? item?.type ==
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
          : ["document", "docx", "doc"]?.includes(
              item?.split(".")[item?.split(".")?.length - 1]
            )) && (
          <div className={classes.pdfView}>
            <span
              onClick={(e) => {
                e.stopPropagation();
                window.open(
                  typeof item == "string"
                    ? mediaUrl(item)
                    : URL.createObjectURL(item),
                  "_blank"
                );
              }}
            >
              <AiFillEye
                color="var(--white-color)"
                size={22}
                style={{ cursor: "pointer" }}
              />
            </span>
            <div>
              <AiFillFileWord size={40} color={`#004db3`} />
              <p>{typeof item == "string" ? item?.slice(7) : item?.name}</p>
            </div>
          </div>
        )
      )}
    </>
  );
};

const rejectFilesError = (rejectedFiles, maxSize, maxFiles) => {
  for (let i = 0; i < rejectedFiles?.length; i++) {
    for (let j = 0; j < rejectedFiles?.[i]?.errors?.length; j++) {
      let code = rejectedFiles?.[i]?.errors?.[j]?.code;
      if (code === "file-too-large") {
        return toast.warn(
          `File size should be less than ${maxSize / 1000000}MB`
        );
      } else if (code === "file-invalid-type") {
        return toast.warn(`Invalid file format`);
      } else if (code === "too-many-files") {
        return toast.warn(`You can upload maximum ${maxFiles} files`);
      }
    }
  }
};
