import classes from "./ProductsCard.module.css";
import { GoDotFill } from "react-icons/go";
import { SlOptionsVertical } from "react-icons/sl";
import { useRef, useState } from "react";
import PopperComponent from "../PopperComponent";

export default function ProductsCard({ item, index }) {
  const popperOptions = [
    { label: "View", value: "View" },
    { label: "Edit", value: "Edit" },
    { label: "Deactivate", value: "Deactivate" },
    { label: "Delete", value: "Delete" },
  ];
  const ref = useRef(null);
  const [indexRef, setIndexRef] = useState(null);
  const [popper, setPopper] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);

  const popperHandler = (item, index) => {
    setSelectedItem(item);
    setIndexRef(index);
    setTimeout(() => {
      setPopper((prev) => !prev);
    }, 300);
  };

  const handleClick = (option) => {
    if (option == "delete") {
    } else if (option == "view") {
    } else if (option == "edit") {
    } else if (option == "deactivate") {
    }
  };
  return (
    <>
      <div className={classes.card}>
        <div className={classes.cardImg}>
          <div className={classes.status}>
            <span>
              <GoDotFill size={20} /> {item.status}
            </span>
          </div>
          <div className={classes.imgDiv}>
            <img src={item.img} className={classes.img} />
          </div>
          <div className={classes.slOptions}>
            <span
              ref={indexRef === index ? ref : null}
              onClick={() => popperHandler(item, index)}
            >
              <SlOptionsVertical />
            </span>
          </div>
        </div>
        <div className={classes.cardDetail}>
          <h5>{item.name}</h5>

          <div className={classes.stock}>
            <p>In Stock:</p>
            <p>{item.stock} Kg/Dozen</p>
          </div>
          <hr />
          <div className={classes.stock}>
            <p>Quality:</p>
            <p>{item.quality}</p>
          </div>
          <hr />

          <p className={classes.price}>
            <span>${item.price}/</span> Kg/Dozen
          </p>

          <p className={classes.des}>{item.des}</p>
        </div>
      </div>

      <PopperComponent
        anchorRef={ref}
        open={popper}
        setOpen={setPopper}
        handleClick={handleClick}
        data={popperOptions}
      />
    </>
  );
}
