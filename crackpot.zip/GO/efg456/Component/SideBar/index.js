import React, { cloneElement, useState } from "react";
import { BiBookContent } from "react-icons/bi";
import { FaBoxOpen } from "react-icons/fa";
import { BiSolidShoppingBags } from "react-icons/bi";
import { FaWallet } from "react-icons/fa6";
import { FiDollarSign } from "react-icons/fi";
import { HiOutlineChatBubbleOvalLeft } from "react-icons/hi2";
import { IoMdNotificationsOutline } from "react-icons/io";
import { IoSettings, IoWallet } from "react-icons/io5";
import { FaUsers } from "react-icons/fa6";
import { TiHome } from "react-icons/ti";
import { FaPercent } from "react-icons/fa6";
import { RiArrowDownSFill, RiArrowUpSFill } from "react-icons/ri";
import { useDispatch } from "react-redux";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Logo } from "../../constant/imagePath";
import { signOutRequest } from "../../store/auth/authSlice";
import { Button } from "../Button/Button";
import classes from "./SideBar.module.css";
const RenderItem = ({ icon, title, subMenu = [], path }) => {
  const active = useLocation()?.pathname;
  const [subnav, setSubnav] = useState(false);
  const subActive = subMenu.find((item) => item?.path == active);
  const showSubnav = () => setSubnav(!subnav);
  const cmsPath = [
    "/cms/home",
    "/cms/services",
    "/cms/about",
    "/cms/portfolio",
    "/cms/privacy-policy",
    "/cms/terms-and-conditions",
    "/cms/contact",
    "/cms/footer",
    "/cms/header",
  ];

  return (
    <>
      <Link
        className={[
          classes?.listItemContainer,
          path == active && classes?.active,
          subActive && classes?.subActive,
          subnav && classes.subExpanded,
          cmsPath.includes(active) &&
            subMenu?.length > 0 &&
            classes?.activeSubNav,
        ].join(" ")}
        to={subMenu?.length > 0 ? "#" : path}
        onClick={() => {
          if (subMenu?.length > 0) {
            showSubnav(!subnav);
          }
        }}
      >
        <span className={classes.icon}>
          {icon && cloneElement(icon, { size: 24 })}
        </span>
        <span className={classes.title}>{title}</span>
        {subMenu?.length > 0 &&
          (subnav ? (
            <RiArrowUpSFill size={20} className={classes?.dropDownIcon} />
          ) : (
            <RiArrowDownSFill size={20} className={classes?.dropDownIcon} />
          ))}
      </Link>
      {subnav && (
        <div className={classes.subMenu}>
          {subMenu?.map((item, index) => {
            return (
              <Link
                className={[
                  classes?.innerItemContainer,
                  item?.path == active && classes?.subNav,
                ].join(" ")}
                key={index}
                to={item?.path}
              >
                <span className={classes.sub__title}>{item?.label}</span>
              </Link>
            );
          })}
        </div>
      )}
    </>
  );
};

const SideBar = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  // const socket = io(apiUrl);

  const HandleSubmitSignOut = () => {
    dispatch(signOutRequest());
    navigate("/login");
  };

  const disputesMenu = [
    { label: "Before 7 Days", path: "/disputes-resolution/before-7days" },
    { label: "After 7 Days", path: "/disputes-resolution/after-7days" },
    { label: "Completed", path: "/disputes-resolution/completed" },
  ];

  const transactionMenu = [
    { label: "Upcoming Requests", path: "/transactions/upcoming-requests/" },
    { label: "Paid Transaction", path: "/transactions/paid-transaction/" },
    {
      label: "Disputed Transaction",
      path: "/transactions/disputed-transaction/",
    },
  ];

  return (
    <div className={classes?.mainContainer}>
      <div className={classes?.logoContainer}>
        <img src={Logo} onClick={() => navigate("/")} />
      </div>
      <div className={classes.itemsContainer}>
        <RenderItem icon={<TiHome />} title={"Home"} path={"/"} />
        <RenderItem
          icon={<FaBoxOpen />}
          title={"Products"}
          path={"/products"}
        />
        <RenderItem
          icon={<BiSolidShoppingBags />}
          title={"Orders"}
          path={"/orders"}
        />
        <RenderItem icon={<IoWallet />} title={"E-Wallet"} path={"/e-wallet"} />
        <RenderItem
          icon={<FaUsers />}
          title={"Users"}
          path={"/user-management"}
        />
        {/* <RenderItem
          icon={<LiaFileContractSolid />}
          title={"Contract Management"}
          path={"/contract-management"}
        />
        <RenderItem
          icon={<FiDollarSign />}
          title={"Transactions"}
          path={""}
          subMenu={transactionMenu}
        />

        <RenderItem
          icon={<IoMdNotificationsOutline />}
          title={"Notifications"}
          path={"/notifications"}
        />
        <RenderItem
          icon={<PiSealWarning />}
          path={""}
          title={"Dispute Resolution"}
          subMenu={disputesMenu}
        />
        <RenderItem
          icon={<HiOutlineChatBubbleOvalLeft />}
          title={"Chat"}
          path={"/chat"}
        />*/}
        <RenderItem
          icon={<FaPercent />}
          title={"Commission"}
          path={"/commission"}
        />
        <RenderItem
          icon={<IoSettings />}
          title={"Categories"}
          path={"/categories"}
        />

        <RenderItem icon={<IoSettings />} title={"Setting"} path={"/setting"} />
        <Button className={classes["logout-btn"]} onClick={HandleSubmitSignOut}>
          <span>Logout</span>
        </Button>
      </div>
    </div>
  );
};

export default SideBar;
