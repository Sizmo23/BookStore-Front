import classes from "./RenderData.module.css";
export default function RenderData({ type, label, src, children }) {
  return (
    <div className={classes.wrapper}>
      <label>{label}</label>
      {children}
      {src !== undefined && type === "image" && (
        <div className={classes.image}>
          <img src={src} />
        </div>
      )}
    </div>
  );
}
