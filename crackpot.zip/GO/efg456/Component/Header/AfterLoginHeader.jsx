import React, { useRef, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { userAvatar } from "../../constant/imagePath";
import Emoji from "../Emojis";
import Style from "./AfterLoginHeader.module.css";
export const AfterLoginHeader = ({ className, header, drawerBtn }) => {
  const { user } = useSelector((state) => state?.authReducer);
  const { newNotifications } = useSelector((state) => state?.commonReducer);
  const [showPopper, setShowPopper] = useState(false);
  const popperRef = useRef(null);
  const navigate = useNavigate();

  const popperClickHandler = (val) => {
    if (val === "Settings") {
      navigate("/setting");
    }
  };

  return (
    <div className={`${[Style.navbarContainer, className].join(" ")}`}>
      {drawerBtn && drawerBtn}

      <h6 className={Style.heading}>
        {" "}
        <>
          Welcome Back John Doe
          <Emoji className="" label="waving hand" symbol={0x1f44b} />
        </>
      </h6>

      <div
        className={Style["profile-container"]}
        onClick={() => setShowPopper((prev) => !prev)}
      >
        {/* <div
          className={Style.notifyIconDiv}
          onClick={() => navigate("/notifications")}
        >
          <AiFillBell
            size={30}
            className={Style.notifyIcon}
            color="var(--white-color)"
          />
          <span className={Style.notificationCount}>
            {newNotifications?.length > 0 && newNotifications?.length}
          </span>
        </div> */}
        <div
          className={`${[Style.profileImg]} ${Style["profile-wrapper"]}`}
          ref={drawerBtn ? popperRef : null}
        >
          <img
            src={user?.image ? user?.image : userAvatar}
            alt=""
            layout="fill"
          />
        </div>
        <p
          className={Style["profile-name"]}
          ref={!drawerBtn ? popperRef : null}
        >
          {user?.fullName}
          {/* {showPopper ? (
            <IoIosArrowUp color={"var(--main-color)"} size={20} />
          ) : (
            <IoIosArrowDown color={"var(--main-color)"} size={20} />
          )} */}
        </p>
      </div>
      {/* {showPopper && (
        <PopperComponent
          setOpen={setShowPopper}
          open={showPopper}
          anchorRef={popperRef}
          data={[{ icon: "", value: "Settings" }]}
          popperStyle={{ marginTop: "10px" }}
          handleClick={popperClickHandler}
        />
      )} */}
    </div>
  );
};
