import React from "react";
import { PieChart, Pie, Sector, Cell, ResponsiveContainer } from "recharts";

export default function PieCharts({
  data = [
    { name: "Group A", value: 500 },
    { name: "Group B", value: 150 },
    { name: "Group C", value: 200 },
    { name: "Group D", value: 80 },
    { name: "Group E", value: 70 },
  ],
}) {
  const COLORS = ["#B2DB4F", "#FEA918", "#FFF830", "#D86245", "#4D3617"];
  return (
    <>
      <ResponsiveContainer width="100%">
        <PieChart width="100%">
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius="75%"
            outerRadius="100%"
            fill="#8884d8"
            paddingAngle={0}
            dataKey="value"
          >
            {data?.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={COLORS[index % COLORS.length]}
              />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
    </>
  );
}
