import moment from "moment";

import classes from "./Transaction.module.css";
import { visa } from "../../constant/imagePath";

export default function Transactions({
  heading = "Recent Transactions",
  transactionData,
}) {
  return (
    <>
      <div className={classes.wrapper}>
        <h3>{heading}</h3>

        <div className={classes.scrollWrapper}>
          {transactionData?.map((item, index) => {
            return (
              <>
                <div className={classes.content} key={index}>
                  <div className={classes.rightSide}>
                    <img src={visa} className={classes.image} />

                    <div className={classes.details}>
                      <p
                        style={
                          item?.status == "pending"
                            ? { color: "var(--danger-color)" }
                            : item?.status == "declined"
                            ? { color: "var(--error-color)" }
                            : { color: "var(--secondary-color)" }
                        }
                      >
                        {" "}
                        {Math.sign(item?.amount) == -1 ? "-" : "+"}$
                        {Math.abs(item?.amount)}
                      </p>

                      <p className={classes.date}>
                        {moment(item.date).format("DD/MM/YYYY")}
                      </p>
                    </div>
                  </div>
                  <div
                    className={[classes.statusDiv, classes[item.status]].join(
                      " "
                    )}
                  >
                    <span></span> <p>{item.status}</p>
                  </div>
                </div>
                <hr />
              </>
            );
          })}
        </div>
      </div>
    </>
  );
}
