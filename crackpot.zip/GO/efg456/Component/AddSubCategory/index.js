import React from "react";
import classes from "./AddSubCategory.module.css";
import { FiPlusCircle } from "react-icons/fi";
import { Button } from "../Button/Button";
import { MdDelete } from "react-icons/md";
import { toast } from "react-toastify";
import { Input } from "../Input";
import { DropDown } from "../DropDown/DropDown";
import { useSelector } from "react-redux";
const AddSubCategory = ({
  products,
  setProducts,
  addMultiple = true,
  heading = "Sub Categories",
}) => {
  const { productUnits } = useSelector((state) => state?.commonReducer);

  const handleSubcategory = (index, value, key) => {
    setProducts((prev) => {
      const temp = [...prev];
      temp[index][key] = value;
      return temp;
    });
  };
  return (
    <>
      <div className={classes.__header}>
        <p className={classes.__title}>{heading}</p>
        {addMultiple && (
          <Button
            leftIcon={<FiPlusCircle size={12} color={"var(--accent-color)"} />}
            className={classes.addBtn}
            label={"Add"}
            onClick={() => {
              for (let i = 0; i < products.length; i++) {
                if (!products[i]?.productName) {
                  return toast.error(`Enter Sub Category Name`);
                }
                if (!products[i]?.productUnitId) {
                  return toast.error(`Select Sub Category Unit`);
                }
              }
              setProducts((prev) => [
                ...prev,
                { productName: "", productUnitId: null },
              ]);
            }}
          />
        )}
      </div>
      {products?.map((item, index) => {
        return (
          <div className={classes.subcategoryInput}>
            <Input
              value={item?.productName}
              setter={(value) => handleSubcategory(index, value, "productName")}
              placeholder={"Enter Sub Category Name"}
            />
            <DropDown
              value={item?.productUnitId}
              setter={(value) =>
                handleSubcategory(index, value, "productUnitId")
              }
              options={productUnits}
              placeholder={"Select Units"}
              isSearchable={false}
              optionValue={"id"}
              optionLabel={"unitName"}
            />
            {products?.length > 1 && (
              <div
                className={classes.crossIcon}
                onClick={() => {
                  setProducts((prev) => {
                    let temp = [...prev];
                    temp.splice(index, 1);
                    return temp;
                  });
                }}
              >
                <MdDelete size={20} />
              </div>
            )}
          </div>
        );
      })}
    </>
  );
};

export default AddSubCategory;
