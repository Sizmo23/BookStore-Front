import React from "react";
import ModalSkeleton from "../ModalSkeleton";
import { useSelector } from "react-redux";
import { Get } from "../../Axios/AxiosFunctions";
import NoData from "../../Component/NoData/NoData";
import classes from "./ViewCategoryModal.module.css";
import { BaseURL } from "../../config/apiUrl";
import { Loader } from "../../Component/Loader";
import { Skeleton } from "@mui/material";
function ViewCategoryModal({ item, show, setShow }) {
  const { access_token } = useSelector((state) => state?.authReducer);
  const [data, setData] = React.useState(null);
  const [loading, setLoading] = React.useState(false);
  const handleGetData = async () => {
    const apiUrl = BaseURL(`ProductCategory?id=${item?.id}`);
    setLoading("mainLoading");
    const response = await Get(apiUrl, access_token);
    if (response !== undefined) {
      setData(response?.data?.data);
    }
    setLoading(false);
  };

  React.useEffect(() => {
    handleGetData();
  }, []);
  return (
    <ModalSkeleton
      show={show}
      setShow={setShow}
      headerClass={classes.header}
      headerStyles={{ fontFamily: "var(--ff-primary-med)" }}
      header={"View Category"}
      modalClass={classes.modalWrapper}
    >
      <div className={classes.modal}>
        {loading === "mainLoading" ? (
          <>
            <CustomLoader />
          </>
        ) : (
          <>
            <div className={classes.imageWrapper}>
              <img src={data?.image} />
            </div>
            <div className={classes.status}>
              <span></span>
              <p>{data?.isEnabled ? "Active" : "Inactive"}</p>
            </div>
            <div className={classes.infoWrapper}>
              <div className={classes.infoItem}>
                <p>{data?.productCategoryName}</p>
              </div>
              <div className={classes.subCategorysDiv}>
                <p> Sub Categories ({data?.products?.length || 0})</p>
                <div className={classes.subCategorysList}>
                  {data?.products?.length > 0 ? (
                    data?.products?.map((item) => (
                      <div className={classes.item}>
                        <p>{item?.productName}</p>
                      </div>
                    ))
                  ) : (
                    <div className={classes.NoData}>
                      <p>No sub-categories</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </ModalSkeleton>
  );
}

export default ViewCategoryModal;
const CustomLoader = () => {
  return (
    <div className={classes.loader}>
      <Skeleton
        variant="rounded"
        sx={{
          transform: "scale(1)",
          height: "170px",
          marginTop: "10px",

          width: "100%",
        }}
      />
      <div style={{ width: "100%" }}>
        <div>
          <Skeleton
            variant="rounded"
            sx={{
              transform: "scale(1)",
              height: "20px",
              marginTop: "20px",
              marginBottom: "px",
              width: "50px",
            }}
          />
          <Skeleton
            variant="rounded"
            sx={{
              transform: "scale(1)",
              height: "20px",
              marginTop: "10px",
              marginBottom: "15px",
              width: "70px",
            }}
          />
        </div>

        <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
          {Array(7)
            .fill(0)
            .map((item, index) => (
              <Skeleton
                sx={{
                  transform: "scale(1)",
                  height: "30px",
                  marginTop: "0px",
                  marginBottom: "0px",
                  width: index % 2 == 0 ? "60px" : "90px",
                }}
              />
            ))}
        </div>
      </div>
    </div>
  );
};
