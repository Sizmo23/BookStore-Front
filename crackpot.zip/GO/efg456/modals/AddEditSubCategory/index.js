import React, { useState } from "react";
import ModalSkeleton from "../ModalSkeleton";
import classes from "./AddEditSubCategory.module.css";
import AddSubCategory from "../../Component/AddSubCategory";
import { Button } from "../../Component/Button/Button";
const AddEditSubCategory = ({ show, setShow, data, modalLoading, onClick }) => {
  const [products, setProducts] = useState([
    {
      productName: data?.productName || "",
      productUnitId: data?.productUnitId || null,
    },
  ]);
  const handleSubmit = () => {
    const params = {
      products: products?.map((item) => ({
        ...item,
        productUnitId: item?.productUnitId?.id,
      }))[0],
    };
    onClick(params?.products);
  };
  return (
    <>
      <ModalSkeleton show={show} setShow={setShow} width={"750px"}>
        <div className={classes.main_container}>
          <div className={classes.header}>
            <h1> Sub Category</h1>
          </div>
          <div className={classes.sub_category}>
            <AddSubCategory
              addMultiple={false}
              products={products}
              setProducts={setProducts}
              heading={data ? "Edit Sub Category" : "Add Sub Category"}
            />
          </div>
          <div className={classes.actionBtn}>
            <Button
              label={modalLoading ? "Submitting..." : `Submit`}
              disabled={modalLoading}
              onClick={handleSubmit}
            />
          </div>
        </div>
      </ModalSkeleton>
    </>
  );
};

export default AddEditSubCategory;
