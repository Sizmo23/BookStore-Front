import React, { useState } from "react";
import classes from "./ChangeOrderStatus.module.css";
import ModalSkeleton from "../ModalSkeleton";
import { DropDown } from "../../Component/DropDown/DropDown";
import { Button } from "../../Component/Button/Button";
import { toast } from "react-toastify";
import { orderStatusOptions } from "../../config/AppData";
const ChangeOrderStatus = ({ show, setShow, data, onClick, loading }) => {
  const [status, setStatus] = useState(
    orderStatusOptions?.find((ele) => ele?.label === data?.orderStatus) ||
      null
  );
  const handleSubmit = async () => {
    if (!status) {
      toast.error("Status is Required");
      return;
    }
    onClick(status?.value);
  };
  return (
    <>
      <ModalSkeleton
        show={show}
        setShow={setShow}
        header="Change Order Status"
        className={classes.modal}
        width={'650px'}
      >
        <div className={classes.status_container}>
          <DropDown
            value={status}
            setter={setStatus}
            options={orderStatusOptions}
            placeholder={"Select Status"}
            label={`Status (Current: ${data?.orderStatus})`}
          />
          <div className={classes.actions}>
            <Button
              label={loading ? "Submitting..." : "Submit"}
              onClick={handleSubmit}
              disabled={loading}
            />
          </div>
        </div>
      </ModalSkeleton>
    </>
  );
};

export default ChangeOrderStatus;
