import React, { useState } from "react";
import { Col, Row } from "react-bootstrap";
import { Button } from "../../Component/Button/Button";
import ModalSkeleton from "../ModalSkeleton";
import classes from "./AddMemberModal.module.css";
import { formRegEx, formRegExReplacer } from "../../config/apiUrl";
import { toast } from "react-toastify";
import { DropDown } from "../../Component/DropDown/DropDown";
import { useEffect } from "react";
import { useSelector } from "react-redux";

function AddMemberModal({
  show,
  setShow,
  handleClick,
  isLoading,
  allAgents,
  selectedRoom,
}) {
  const { user } = useSelector((state) => state?.authReducer);
  const [agents, setAgents] = useState([]);
  const [otherAgencyAgents, setOtherAgencyAgents] = useState([]);
  const handleSubmit = async () => {
    const params = {
      roomId: selectedRoom?._id,
      userIds: [
        ...agents?.map((item) => item?._id),
        ...otherAgencyAgents?.map((item) => item?._id),
        user?._id,
      ],
    };
    for (let key in params) {
      if (!params[key] || params[key]?.length == 0) {
        return toast.error(
          `${key.replace(formRegEx, formRegExReplacer)} is required!`,
        );
      }
    }
    await handleClick(params);
  };

  useEffect(() => {
    if (selectedRoom) {
      const otherAgnecyAgentsFilteredOut = selectedRoom?.users
        ?.map((item) => item?.userId)
        ?.filter((item) => item?._id !== user?._id)
        ?.map(
          (el) =>
            allAgents?.map((innerEl) => innerEl?._id)?.includes(el?._id) && el,
        )
        ?.filter(Boolean);
      setAgents(otherAgnecyAgentsFilteredOut || []);
      setOtherAgencyAgents(
        selectedRoom?.users
          ?.map((item) => item?.userId)
          ?.filter((item) => item?._id !== user?._id)
          ?.map(
            (el) =>
              !allAgents?.map((innerEl) => innerEl?._id)?.includes(el?._id) &&
              el,
          )
          ?.filter(Boolean) || [],
      );
    }
  }, [selectedRoom]);

  return (
    <>
      <style>
        {`
        .modal-content{
            overflow: visible !important;
          }
        `}
      </style>
      <ModalSkeleton
        show={show}
        setShow={setShow}
        width="600px"
        borderRadius="20px"
        header={`Add Agents`}
      >
        <div className={classes.container}>
          <Row className={classes.row}>
            <Col md={12}>
              <DropDown
                placeholder={"Select Agents"}
                options={allAgents || []}
                setter={setAgents}
                value={agents}
                getOptionLabel={(option) => {
                  return `${option["firstName"]} ${option["lastName"]}`;
                }}
                optionValue={"_id"}
                isMulti={true}
                isSearchable={true}
              />
            </Col>

            <Col md={12} className={classes.btn_main}>
              <Button
                label={isLoading ? "Submitting..." : "Submit"}
                onClick={handleSubmit}
                className={classes.btn}
                disabled={isLoading}
              />
            </Col>
          </Row>
        </div>
      </ModalSkeleton>
    </>
  );
}

export default AddMemberModal;
