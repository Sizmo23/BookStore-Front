import React from "react";
import { useSelector } from "react-redux";
import { Get } from "../../Axios/AxiosFunctions";
import { Loader } from "../../Component/Loader";
import { BaseURL } from "../../config/apiUrl";
import ModalSkeleton from "../ModalSkeleton";
import classes from "./ViewProductModal.module.css";
import { tomato } from "../../constant/imagePath";
import { Skeleton } from "@mui/material";
function ViewProductModal({ selectedItem, show, setShow }) {
  const {
    authReducer: { access_token = "" } = {},
    commonReducer: { productUnits = [], productQuality = [] } = {},
  } = useSelector((state) => state);

  const [item, setItem] = React.useState(null);
  const [loading, setLoading] = React.useState(false);
  const handleGetData = async () => {
    const apiUrl = BaseURL(`VendorProduct?id=${selectedItem?.id}`);
    setLoading("mainLoading");
    const response = await Get(apiUrl, access_token);
    if (response !== undefined) {
      const unit = productUnits?.find(
        (item) => item?.id === response?.data?.data?.productUnitId
      );
      const quality = productQuality?.find(
        (item) => item?.id === response?.data?.data?.productQualityId
      );
      setItem({ ...response?.data?.data, unit, quality });
    }
    setLoading(false);
  };

  React.useEffect(() => {
    handleGetData();
  }, []);
  return (
    <ModalSkeleton
      show={show}
      setShow={setShow}
      headerClass={classes.header}
      headerStyles={{ fontFamily: "var(--ff-primary-med)" }}
      header={"View Product"}
      modalClass={classes.modalWrapper}
    >
      <div className={classes.modal}>
        {loading === "mainLoading" ? (
          <CustomLoader />
        ) : (
          <div className={classes.card}>
            <div className={classes.status}>
              <span>{item?.isEnabled ? "Active" : "Inactive"}</span>
            </div>
            <div className={classes.imgDiv}>
              <img src={item?.img || tomato} />
            </div>

            <div className={classes.cardDetail}>
              <h5>{item?.productName}</h5>

              <div className={classes.stock}>
                <p>In Stock: {item?.quantity}</p>
                <p>{item?.unit?.unitName} </p>
              </div>
              <hr />
              <div className={classes.stock}>
                <p>Quality</p>
                <p>{item?.quality?.productQualityName}</p>
              </div>
              <hr />

              <p className={classes.price}>
                <span>${item?.amount}</span>
              </p>

              <p className={classes.des}>{item?.description}</p>
            </div>
          </div>
        )}
      </div>
    </ModalSkeleton>
  );
}

export default ViewProductModal;

const CustomLoader = () => {
  return (
    <div className={classes.loader}>
      <Skeleton
        variant="rounded"
        sx={{
          transform: "scale(1)",
          height: "130px",
          marginTop: "10px",

          width: "100%",
        }}
      />
      <div style={{ width: "100%" }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          <Skeleton
            variant="rounded"
            sx={{
              transform: "scale(1)",
              height: "20px",
              marginTop: "10px",
              marginBottom: "px",
              width: "60px",
            }}
          />
          <Skeleton
            variant="rounded"
            sx={{
              transform: "scale(1)",
              height: "20px",
              marginTop: "10px",
              marginBottom: "0px",
              width: "80px",
            }}
          />
        </div>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          <Skeleton
            sx={{
              transform: "scale(1)",
              height: "20px",
              marginTop: "5px",
              marginBottom: "5px",
              width: "90px",
            }}
          />
          <Skeleton
            sx={{
              transform: "scale(1)",
              height: "20px",
              marginTop: "5px",
              marginBottom: "5px",
              width: "60px",
            }}
          />
        </div>
        <div>
          <Skeleton
            sx={{
              transform: "scale(1)",
              height: "20px",
              marginTop: "5px",
              marginBottom: "5px",
              width: "70px",
            }}
          />
          <Skeleton
            sx={{
              transform: "scale(1)",
              height: "80px",
              marginTop: "0px",
              marginBottom: "10px",
              width: "100%",
            }}
          />
        </div>
      </div>
    </div>
  );
};
