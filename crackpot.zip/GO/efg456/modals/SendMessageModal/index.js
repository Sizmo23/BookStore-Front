import React, { useState } from "react";
import { Col, Row } from "react-bootstrap";
import { Button } from "../../Component/Button/Button";
import ModalSkeleton from "../ModalSkeleton";
import classes from "./SendMessage.module.css";
import { formRegEx, formRegExReplacer } from "../../config/apiUrl";
import { toast } from "react-toastify";
import { DropDown } from "../../Component/DropDown/DropDown";

function SendMessageModal({
  show,
  setShow,
  handleClick,
  isLoading,
  allAgents,
}) {
  const [agents, setAgents] = useState([]);
  const handleSubmit = async () => {
    const params = {
      userIds: agents?.map((item) => item?._id),
    };
    for (let key in params) {
      if (!params[key] || params[key]?.length == 0) {
        return toast.error(
          `${key.replace(formRegEx, formRegExReplacer)} is required!`,
        );
      }
    }
    await handleClick(params);
  };
  return (
    <>
      <style>
        {`
        .modal-content{
            overflow: visible !important;
          }
        `}
      </style>
      <ModalSkeleton
        show={show}
        setShow={setShow}
        width="600px"
        borderRadius="20px"
        header={`Start Chat`}
      >
        <div className={classes.container}>
          <Row className={classes.row}>
            <Col md={12}>
              <DropDown
                placeholder={"Select agents"}
                options={allAgents || []}
                setter={setAgents}
                value={agents}
                getOptionLabel={(option) => {
                  return `${option["firstName"]} ${option["lastName"]}`;
                }}
                optionValue={"_id"}
                isMulti={true}
                isSearchable={true}
              />
            </Col>

            <Col md={12} className={classes.btn_main}>
              <Button
                label={isLoading ? "Submitting..." : "Submit"}
                onClick={handleSubmit}
                className={classes.btn}
                disabled={isLoading}
              />
            </Col>
          </Row>
        </div>
      </ModalSkeleton>
    </>
  );
}

export default SendMessageModal;
