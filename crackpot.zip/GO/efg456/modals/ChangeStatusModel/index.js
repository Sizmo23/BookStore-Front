import React, { useState } from "react";
import ModalSkeleton from "../ModalSkeleton";
import { DropDown } from "../../Component/DropDown/DropDown";
import { Button } from "../../Component/Button/Button";
import classes from "./ChangeStatusModel.module.css";

const ChangeStatusModel = ({
  options,
  onClick,
  loader,
  currentValue,
  show,
  setShow,
}) => {
  const [selectedItem, setSelectedItem] = useState(currentValue);

  const handleChange = () => {
    onClick(selectedItem?.value);
  };

  return (
    <ModalSkeleton show={show} setShow={setShow} width={"650px"}>
      <div className={classes.heading}>
        <h1>Change Status</h1>
      </div>
      <div className={classes.main}>
        <div className={classes.dropDown}>
          <DropDown
            options={options}
            value={selectedItem}
            setter={setSelectedItem}
          />
        </div>

        <div className={classes.btn}>
          <Button
            className={classes.btnMain}
            disabled={loader}
            onClick={handleChange}
            label={loader ? "Changing" : "Change"}
          />
        </div>
      </div>
    </ModalSkeleton>
  );
};

export default ChangeStatusModel;

// import React from "react";
// import ModalSkeleton from "../ModalSkeleton";

// function ChangeStatusModel({ setShow, show, currentValue, data }) {
//   return (
//     <ModalSkeleton setShow={setShow} show={show}>
//       <div>
//         <h1>Helo</h1>
//         {/* <DropDown
//           options={options}
//           value={selectedItem}
//           setter={setSelectedItem}
//         /> */}
//       </div>
//     </ModalSkeleton>
//   );
// }

// export default ChangeStatusModel;
