import { corn } from "../constant/imagePath";
import moment from "moment";

export const UserManagementData = Array.from({ length: 10 }).map(() => {
  return {
    buyerId: "#000000",
    buyerName: "John",
    date: moment(Date.now()).format("DD-MM-YYYY"),
  };
});

export const data1 = [
  { name: "Group A", value: 50 },
  { name: "Group B", value: 35 },
  { name: "Group C", value: 15 },
];
export const data2 = [
  { name: "Group A", value: 500 },
  { name: "Group B", value: 150 },
  { name: "Group C", value: 200 },
  { name: "Group D", value: 80 },
  { name: "Group E", value: 70 },
];

export const productsData = [
  {
    productId: 1,
    productName: "Widget A",
    productCategory: "Electronics",
    productSubCategory: "Gadgets",
  },
  {
    productId: 2,
    productName: "Gizmo B",
    productCategory: "Home & Kitchen",
    productSubCategory: "Appliances",
  },
  {
    productId: 3,
    productName: "Thingamajig C",
    productCategory: "Toys & Games",
    productSubCategory: "Educational",
  },
  {
    productId: 4,
    productName: "Doodad D",
    productCategory: "Clothing",
    productSubCategory: "Casual Wear",
  },
  {
    productId: 5,
    productName: "Whatsit E",
    productCategory: "Books",
    productSubCategory: "Fiction",
  },
];

export const ordersData = [
  {
    vendorId: 101,
    vendorName: "ABC Corporation",
    buyerId: 201,
    orderedProductQuantity: "Product Name x 5",
    status: "pending",
    buyerName: "John",
    action: "Edit",
  },
  {
    vendorId: 102,
    vendorName: "XYZ Suppliers",
    buyerId: 202,
    orderedProductQuantity: "Product Name x 5",
    buyerName: "John",

    status: "delivered",
    action: "Delete",
  },
  {
    vendorId: 103,
    vendorName: "LMN Enterprises",
    buyerId: 203,
    orderedProductQuantity: "Product Name x 5",
    buyerName: "John",

    status: "disputed",
    action: "View",
  },
  {
    vendorId: 104,
    vendorName: "PQR Industries",
    buyerId: 204,
    orderedProductQuantity: "Product Name x 5",
    buyerName: "John",

    status: "pending",
    action: "Approve",
  },
  {
    vendorId: 105,
    vendorName: "EFG Ltd.",
    buyerId: 205,
    orderedProductQuantity: "Product Name x 5",
    buyerName: "John",

    status: "delivered",
    action: "Review",
  },
];

export const transactionData = [
  {
    id: 1,
    img: "/images/visa.png",
    amount: -22,
    date: Date.now(),
    status: "pending",
  },
  {
    id: 2,
    img: "/images/visa.png",
    amount: -22,
    date: Date.now(),
    status: "approved",
  },
  {
    id: 3,
    img: "/images/visa.png",
    amount: 322,
    date: Date.now(),
    status: "declined",
  },
  {
    id: 4,
    img: "/images/visa.png",
    amount: -22,
    date: Date.now(),
    status: "pending",
  },
  {
    id: 5,
    img: "/images/visa.png",
    amount: -22,
    date: Date.now(),
    status: "approved",
  },
  {
    id: 6,
    img: "/images/visa.png",
    amount: 322,
    date: Date.now(),
    status: "declined",
  },
];

export const AllCardData = [
  {
    status: "Active",
    img: corn,
    name: "Fruit Name Will Be Here",
    stock: "000",
    quality: "A1 Quality",
    price: "00.00",
    des: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard",
  },
  {
    status: "Active",
    img: corn,
    name: "Fruit Name Will Be Here",
    stock: "000",
    quality: "A1 Quality",
    price: "00.00",
    des: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard",
  },
  {
    status: "Active",
    img: corn,
    name: "Fruit Name Will Be Here",
    stock: "000",
    quality: "A1 Quality",
    price: "00.00",
    des: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard",
  },
  {
    status: "Active",
    img: corn,
    name: "Fruit Name Will Be Here",
    stock: "000",
    quality: "A1 Quality",
    price: "00.00",
    des: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard",
  },
  {
    status: "Active",
    img: corn,
    name: "Fruit Name Will Be Here",
    stock: "000",
    quality: "A1 Quality",
    price: "00.00",
    des: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard",
  },
  {
    status: "Active",
    img: corn,
    name: "Fruit Name Will Be Here",
    stock: "00.00",
    quality: "A1 Quality",
    price: "000",
    des: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard",
  },
  {
    status: "Active",
    img: corn,
    name: "Fruit Name Will Be Here",
    stock: "00.00",
    quality: "A1 Quality",
    price: "000",
    des: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard",
  },
];

export const withdrawalRequests = [
  {
    vendorId: "#0000",
    vendorName: "Name Here",
    amount: "00.00",
    date: Date.now(),
    status: "pending",
  },
  {
    vendorId: "#0001",
    vendorName: "Name Here",
    amount: "00.00",
    date: Date.now(),
    status: "disputed",
  },
  {
    vendorId: "#0002",
    vendorName: "Name Here",
    amount: "00.00",
    date: Date.now(),
    status: "pending",
  },
  {
    vendorId: "#0003",
    vendorName: "Name Here",
    amount: "00.00",
    date: Date.now(),
    status: "disputed",
  },
  {
    vendorId: "#0004",
    vendorName: "Name Here",
    amount: "00.00",
    date: Date.now(),
    status: "pending",
  },
  {
    vendorId: "#0005",
    vendorName: "Name Here",
    amount: "00.00",
    date: Date.now(),
    status: "disputed",
  },
];

export const graphData = [
  {
    name: "JAN",
    uv: 9000,
    value: "$9000",
  },
  {
    name: "FEB",
    uv: 3000,
    value: "$3000",
  },
  {
    name: "MAR",
    uv: 2000,
    value: "$2000",
  },
  {
    name: "APR",
    value: "$2780",

    uv: 2780,
  },
  {
    name: "MAY",
    value: "$1890",

    uv: 1890,
  },
  {
    name: "JUN",
    uv: 2390,
    value: "$2390",
  },
  {
    name: "JUL",
    uv: 300,
    value: "$300",
  },
  {
    name: "AUG",
    uv: 3490,
    value: "$3490",
  },
  {
    name: "SEP",
    uv: 111,
    value: "$111",
  },
  {
    name: "OCT",
    uv: 320,
    value: "$320",
  },
  {
    name: "NOV",
    uv: 900,
    value: "$900",
  },
  {
    name: "DEC",
    uv: 90,
    value: "$90",
  },
];
