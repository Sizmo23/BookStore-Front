// Products Page

import { FaMoneyBillAlt } from "react-icons/fa";
import {
  FaEye,
  FaMoneyBills,
  FaTrash,
  FaUser,
  FaWallet,
} from "react-icons/fa6";
import { GiStrawberry, GiTomato } from "react-icons/gi";
import { PiTennisBall } from "react-icons/pi";
import { corn } from "../constant/imagePath";

export const ProductsTabsOptions = [
  { label: `All`, value: "", icon: <PiTennisBall /> },
  {
    label: `Fruits`,
    value: "fruits",
    icon: <GiStrawberry />,
  },
  {
    label: `Vegetables`,
    value: "vegetables",
    icon: <GiTomato />,
  },
];
export const ProductsFilterOptions = [
  {
    label: "All",
    value: "",
  },
  {
    label: "Active",
    value: true,
  },
  {
    label: "Inactive",
    value: false,
  },
];

// User Management Page
export const UserManagementTabs = [
  {
    label: `Buyers`,
    value: 3,
    icon: <FaUser />,
  },
  {
    label: `Vendors`,
    value: 2,
    icon: <FaUser />,
  },
];

export const UserPopperOptions = [
  {
    icon: <FaTrash />,
    label: "Delete",
    value: "Delete",
  },
];
// Add category Page
export const AddProductIdOptions = [
  {
    label: "Product 1 ID",
    value: "1",
  },
  {
    label: "Product 2 ID",
    value: "2",
  },
  {
    label: "Product 3 Id",
    value: "3",
  },
];
// Orders
export const OrderPopperOptions = [
  {
    icon: <FaEye />,
    label: "View",
    value: "View",
  },
  {
    icon: <FaTrash />,
    label: "Delete",
    value: "Delete",
  },
];
// E-Wallet
export const EWalletTabsOptions = [
  { label: `E-Wallet`, value: "ewallet", icon: <FaWallet /> },
  // {
  //   label: `Withdrawal Requests`,
  //   value: "withdrawalRequests",
  //   icon: <FaMoneyBillAlt />,
  // },
  {
    label: `Transactions`,
    value: "transactions",
    icon: <FaMoneyBills />,
  },
];
export const defaultCategory = {
  productCategoryName: "All",
  id: "",
  image: corn,
};
export const orderStatusOptions = [
  {
    label: "Pending",
    value: 1,
  },
  {
    label: "Delivered",
    value: 2,
  },
  {
    label: "Disputed",
    value: 3,
  },
];
