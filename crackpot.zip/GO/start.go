package main

import "fmt"

func main() {
	fmt.Println("Wow World!")

	var Moiz string = "Woww"

	var Games string = "Noww"

	fmt.Println(Moiz + Games)

	// for x := 0; x < 10; x++ {
	// 	fmt.Println("Here we are", x)
	// }

	var ABC string = foo("Iowa")

	var Division, Remainder int = giveRemainderDivision(121, 11)

	fmt.Printf("The divided answer is %v and the remainder is %v \n", Division, Remainder)

	fmt.Println(ABC)
}

func foo(Stuff string) string {
	return Stuff
}

func giveRemainderDivision(Numerator int, Denominator int) (int, int) {
	var Division int = Numerator / Denominator
	var Remainder int = Numerator % Denominator

	return Division, Remainder
}
